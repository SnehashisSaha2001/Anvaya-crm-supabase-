/* Anvaya CRM — installability.
   One codebase, installable on Windows and macOS (Chrome/Edge), Android
   (Chrome) and iOS (Safari → Add to Home Screen). No app store involved. */
(function () {
  'use strict';

  const standalone =
    window.matchMedia('(display-mode: standalone)').matches ||
    window.navigator.standalone === true;
  const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent);
  const isAndroid = /android/i.test(navigator.userAgent);

  let deferredPrompt = null;
  const btn = document.getElementById('installBtn');

  function showButton() {
    if (!btn || standalone) return;
    btn.hidden = false;
  }

  // Chrome, Edge, Samsung Internet and Android Chrome all fire this.
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    showButton();
  });

  window.addEventListener('appinstalled', () => {
    if (btn) btn.hidden = true;
    deferredPrompt = null;
  });

  // Safari never fires beforeinstallprompt — offer the manual route instead.
  if (isIos && !standalone) showButton();

  // One entry point, used by the header button and the drawer button.
  window.AnvayaInstall = async function triggerInstall() {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      deferredPrompt = null;
      if (choice && choice.outcome === 'accepted' && btn) btn.hidden = true;
      return;
    }
    showInstructions();
  };

  function showInstructions() {
    const steps = isIos
      ? [
          'Open this page in <b>Safari</b> (Chrome on iOS cannot install apps).',
          'Tap the <b>Share</b> button — the square with an arrow, at the bottom.',
          'Scroll down and tap <b>Add to Home Screen</b>.',
          'Tap <b>Add</b>. Anvaya appears on your home screen like any other app.'
        ]
      : isAndroid
        ? [
            'Open the browser menu (three dots, top right).',
            'Tap <b>Install app</b> or <b>Add to Home screen</b>.',
            'Confirm. Anvaya opens in its own window from now on.'
          ]
        : [
            'In Chrome or Edge, look for the <b>install icon</b> in the address bar (a small screen with an arrow).',
            'Or open the browser menu → <b>Apps</b> → <b>Install this site as an app</b>.',
            'On macOS you can also use <b>File → Open in Safari</b>, then <b>Share → Add to Dock</b>.',
            'It gets a desktop icon and opens in its own window, without browser tabs.'
          ];

    const host = document.createElement('div');
    host.className = 'overlay';
    host.style.alignItems = 'stretch';
    host.style.padding = '0';
    host.innerHTML = `
      <div class="sheet" style="width:min(440px,94vw)" role="dialog" aria-label="Install Anvaya">
        <div class="sheet-head">
          <div><div class="card-title">Install Anvaya on this device</div>
            <div class="card-sub">Works on Windows, macOS, Android and iOS</div></div>
          <button class="icon-btn" style="margin-left:auto" data-close aria-label="Close">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
          </button>
        </div>
        <div class="sheet-body">
          <ol style="padding-left:18px;display:flex;flex-direction:column;gap:10px;font-size:12.5px;line-height:1.55;color:var(--text-2)">
            ${steps.map((s) => `<li>${s}</li>`).join('')}
          </ol>
          <div class="metric-note" style="margin-top:14px">
            The installed app keeps your data on this device. If you later connect a server,
            the same app shows shared records instead.
          </div>
        </div>
        <div class="sheet-foot"><button class="btn primary" data-close>Got it</button></div>
      </div>`;
    host.addEventListener('click', (e) => {
      if (e.target === host || e.target.closest('[data-close]')) host.remove();
    });
    document.body.appendChild(host);
  }

  // Register the service worker only over http(s) — file:// has no SW support.
  if ('serviceWorker' in navigator && location.protocol.indexOf('http') === 0) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('sw.js').catch(() => {
        /* offline caching is a bonus; the app works without it */
      });
    });
  }
})();
