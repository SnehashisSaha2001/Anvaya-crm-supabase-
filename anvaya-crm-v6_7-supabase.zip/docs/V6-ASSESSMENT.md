# Anvaya CRM V6 — implementation assessment

Produced after reading the V5 source in this repository: 6,900 lines of backend,
3 migrations, 48 tests. Scope is the CRM only; field-force functionality is out
of scope and no such module exists here.

---

## 1. What V5 already had

| Area | Reality |
|---|---|
| Frontend | `index.html`, `app.js`, `styles.css`, `engine.js`, `data.js`. No build step. Responsive, installable PWA, light and dark. |
| Backend | Express 4, 11 modules under `backend/src`. |
| Database | PostgreSQL 16 (PGlite in-process). 45 tables, 160 RLS policies before this increment. |
| Auth | scrypt passwords, hashed session tokens in httpOnly cookies, 9 role templates enforced twice. |
| Tests | 48 covering API flows, tenant isolation, permissions, audit immutability, capture, keys, webhooks. |

## 2. Feature audit

### Fully implemented in V5

Dashboard · Leads (with one-click conversion) · Deals (drag-and-drop pipeline) ·
Contacts · Companies · Customer 360 · Tasks · Support with SLA state · Products ·
Quotations · Invoices (records only) · Projects · Campaigns · Workflow engine
(trigger → conditions → actions → approval → run logs) · Reports (fixed widgets) ·
Settings with members, roles, custom fields · AI Copilot (two modes) · Global
search · Web forms · Inbound email · API keys · Outbound webhooks · OpenAPI
document · Saved views · Audit log.

### Partially implemented in V5

| Feature | What existed | What was missing |
|---|---|---|
| Authentication | password + session | second factor, backup codes |
| Invoices | rows, amounts, status text | numbering, tax/discount breakdown, balance, overdue detection |
| Payments | a table with rows | recording, partial payment, refunds, reconciliation |
| Documents | nothing | every PDF |
| Gmail / Outlook | OAuth, tokens, mail→activity sync | sending, templates, inbox |
| Workflows | engine + run history | visual canvas |
| Multi-currency | currency column per deal | admin screen, rates, conversion |
| Offline | static edition fully offline | server-edition write queue |
| Navigation | 6 ad-hoc groups | the 7-group structure in the brief |

### Not implemented in V5

MFA · PDF generation · payments · report builder · workflow canvas · layout
builder · dashboard customisation · multi-currency administration.

## 3. Bugs and limitations found in V5

1. **`invoices.total` was the only money column.** Nothing computed subtotal, tax
   or discount, so a GST invoice could not be produced from the data.
2. **`payments.status` used `succeeded`** while other code assumed `success`.
   Unified on the schema's own vocabulary.
3. **`invoice_items` uses `qty` and `line_total`,** not `quantity` and
   `discount`. Any code written against the "obvious" names fails.
4. **No `deleted_at` on invoices,** although several queries filtered on it.
5. **`createSession` returned no session id,** which made per-session flags
   (needed for MFA) impossible. Fixed.
6. **Invoice numbers were client-supplied** and could collide; `unique(org_id,
   number)` would have thrown at the wrong moment.
7. `quote`/`invoice` totals were never recomputed after a line changed.

## 4. Database changes in this increment

Two migrations, both additive — no column dropped, no table renamed, no data
rewritten:

- `004_mfa.sql` — `users.mfa_secret`, `mfa_enabled_at`, `mfa_backup_codes`,
  `mfa_last_used_at`, `sessions.mfa_ok`.
- `005_documents_finance.sql` — `document_sequences`, `document_versions`,
  `payment_links`, `refunds`, `credit_notes`, `payment_events`; new nullable
  columns on `invoices`, `quotations` and `payments`.

Every new table carries `org_id` and RLS policies using the same helper
functions as V5, so tenant isolation applies to the new surface without a second
mechanism.

## 5. Backend changes

| Module | Purpose |
|---|---|
| `src/mfa.js` | TOTP (RFC 6238) on `node:crypto`, backup codes, enrolment, session gating |
| `src/documents.js` | numbering, totals, PDF rendering, version snapshots, branding |
| `src/finance.js` | payments, balances, refunds, credit notes, payment links, webhooks |
| `src/auth.js` | session id returned; pending-MFA sessions refused |
| `src/app.js` | routers mounted before generic resources so `POST /api/invoices` is the financial one |

## 6. Frontend changes

- Navigation rebuilt to the brief's seven groups, filtered by permission.
- New screens: Payments, Security, Audit log, AI Copilot, Global search.
- Invoices gained a PDF action and an inline "Payment" action.
- Nothing existing was removed or redesigned.

## 7. What is deliberately still open

Payments work end to end with the `manual` provider and any signed gateway
webhook. Live Razorpay/Stripe checkout needs your keys. Gmail/Outlook sending,
the report builder, the workflow canvas, the layout builder, dashboard
customisation and the offline write queue are not in this increment; each is
listed with its status in `V6-RELEASE.md` rather than shipped as a shell.
