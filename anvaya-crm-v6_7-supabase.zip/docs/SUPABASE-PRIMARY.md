# Supabase as the primary database, local copy as backup

No existing file was changed. Everything here is additive.

```
Browser (PWA)  ──/api──►  Express backend (unchanged)  ──SQL──►  SUPABASE  (primary)
   │                                                                │
   └─ IndexedDB/localStorage cache + outbox                        └─ mirrored every 30 min ─► local PGlite backup
      (existing offline layer: reads when offline, queues edits)         backend/.data/backup
```

## Why DATABASE_URL, not the anon key

The Express backend speaks PostgreSQL, so it needs the **database password**
connection string. The anon key is a browser key for Supabase's REST API; the
backend cannot use it. The URL and anon key are in `backend/.env` for the link
check and for any future direct-from-browser build.

## Setup (about 10 minutes)

1. **Schema.** Supabase → SQL editor → run `supabase/anvaya-supabase.sql`.
   Create your user (Authentication → Users), then run the file again so the
   workspace is attached to you. *Never* run `npm run migrate` against Supabase.
2. **Connection string.** Supabase → Connect → copy the pooler URI. Paste it into
   `backend/.env` as `DATABASE_URL`, replacing the password placeholder
   (percent-encode `@` as `%40`).
3. **Encryption key.** `openssl rand -base64 48` → `ENCRYPTION_KEY` in `.env`.
4. **Check.** `cd backend && npm ci && node scripts/supabase-link.mjs`
5. **Run.** `node scripts/start-supabase.mjs`

`start-supabase.mjs` sets `AUTO_MIGRATE=0` and `DB_USER_ROLE=authenticated`
(so RLS applies), refuses to start if `DATABASE_URL` is missing (rather than
quietly using a local database), runs the unchanged `src/server.js`, and starts
the backup mirror.

## The two local copies

| Copy | Lives in | Purpose |
|---|---|---|
| Browser cache + outbox | each user's device (existing `offline.js`, `idb.js`, `sync.js`) | keeps screens readable and queues edits when the network or server is down; replays them on reconnect |
| Server backup | `backend/.data/backup` (new `supabase-mirror.mjs`) | full copy of every table, for disaster recovery |

The mirror is **one-way** (Supabase → local), runs in one consistent snapshot,
replaces the backup atomically, and checks row counts before committing. A failed
run keeps the previous backup. It refuses to run as a role that cannot bypass RLS.
`node scripts/supabase-mirror.mjs --once` takes a backup on demand.

## If Supabase is lost or unreachable for long

```bash
cd backend
DB_PATH=./.data/backup node src/server.js      # DATABASE_URL must be unset
```

The app runs on the last backup, unchanged. Writes made there do **not** flow
back to Supabase automatically, by design: automatic two-way merging is how data
gets silently overwritten. Re-import them deliberately once Supabase is back.
The backup holds password hashes and customer data: protect that folder like the
database itself, and do not commit it.

## Security

- Anon key: public by design; the link check also verifies it sees no customer rows.
- Database password: only in `backend/.env`. Never in the frontend or git.
- `service_role` key: not needed. If one was ever pasted anywhere, rotate it.
- Enable Supabase → Database → Backups before real data goes in.

## What was verified, and what was not

Verified here: mirror (copy, edit/delete propagation, rollback on failure, RLS
refusal) against a database built from your real `anvaya-supabase.sql`; the
backend booting on a mirrored backup; the launcher's refusal guard; the full
existing suite (89 of 91; the 2 failures are a hardcoded `/scratch/…` path in
`supabase-doctor.test.js`, unrelated).
**Not verified:** a live connection to your Supabase project. This sandbox cannot
reach `*.supabase.co`. Run `node scripts/supabase-link.mjs` on your machine first.
