# Anvaya CRM — administrator manual

## Roles

Nine templates ship with the product: owner, admin, manager, sales, support,
marketing, finance, field, read-only. Permissions are enforced twice — in the API
route guard and again in PostgreSQL row-level security — so a permission mistake
in one layer is caught by the other. Navigation hides modules a user cannot read.

## Enabling two-factor for everyone

Set the organisation flag:

```sql
update organisations
   set settings = jsonb_set(coalesce(settings,'{}'::jsonb), '{require_mfa}', 'true')
 where id = '<org-uuid>';
```

Users then see a prompt to enrol on the Security screen. Enrolment is per user;
you can see who has enabled it from **Settings → Members**.

## Company branding on documents

**Settings → Company details** stores the legal name, address, GSTIN, bank
details and terms used on every PDF. Set it before issuing your first invoice;
existing documents keep the snapshot they were issued with.

## Invoice numbering

Numbers are allocated per organisation, per document type, inside a transaction:
`INV-2026-0001`, `QTN-2026-0001`, `CRN-2026-0001`. To change the prefix, update
`document_sequences` for that org and type; the next number continues from
`next_number`.

## Payments

Configure a gateway by setting `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET` or
`STRIPE_SECRET_KEY`, plus `PAYMENT_WEBHOOK_SECRET`. Point the provider's webhook
at `POST /api/webhooks/payments/razorpay` (or `/stripe`). Without these the
system runs in manual mode and says so in the API response — it never pretends a
gateway is live.

## Audit and recovery

Every create, edit and delete is written to `audit_logs`. The application role
has no INSERT, UPDATE or DELETE policy on that table, so entries cannot be
forged or erased through the app.

Backups: take a `pg_dump` on a schedule; the database is the only stateful part.
Restore into a fresh instance, run `npm run migrate`, and confirm the schema
version matches before pointing the app at it.

## Environment

See `backend/.env.example`. `ENCRYPTION_KEY` must be at least 32 characters and
must never change once secrets are stored — changing it makes existing MFA
secrets and provider tokens unreadable.
