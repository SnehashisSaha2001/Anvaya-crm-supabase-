# Anvaya CRM V6

A CRM that deploys without surprises.

The reason the earlier builds failed on Vercel was structural: one folder tried to be
both a static site and a Node server, so the platform kept guessing wrong. This rewrite
splits the two, and the split is the whole design:

```
  index.html, app.js, …   the app, at the repo root → deploys anywhere, zero config
  backend/                optional server → deploys to a host that gives it a disk
```

The app files sit at the root on purpose. An earlier version kept them in `web/`, and
deploying that folder served `index.html` while every `styles.css` request 404'd — the
page arrived unstyled. Root-level files with relative paths cannot break that way.

The app at the root works on its own. Add the backend and the same app switches from
browser storage to shared, multi-user records — automatically, with no code change and
no rebuild.

---

## What is here

| Path | What it is |
|---|---|
| `index.html` | the application shell |
| `app.js` | the interface: dashboard, leads, deals, 360, tickets, reports… |
| `engine.js` | the local data engine — the same routes, served from the browser |
| `data.js` | the bridge that picks between the engine and the server |
| `styles.css` | the design system |
| `manifest.webmanifest`, `sw.js`, `pwa.js`, `icons/` | makes it installable and offline-capable |
| `backend/` | optional Express + PostgreSQL server, 38 tables, 134 RLS policies |
| `tools/build-single-file.py` | builds one self-contained .html from the same sources |

---

## Run it locally

Static only — no install at all:

```bash
python3 -m http.server 8000     # from the repo root; open http://localhost:8000
```

With the backend — real database, real accounts:

```bash
cd backend
npm install
npm run seed        # creates the schema and a demo workspace
npm start           # http://localhost:4000  (serves ../web as well)
```

Sign in as **sneha@brightline.in** / **AnvayaDemo2026**.

---

## Deploy

### The app, as a static site — Vercel, Netlify, GitHub Pages, anything

Upload **this folder** (or `anvaya-crm-v3.zip`). `index.html` is at the root, so the host
serves it directly and every relative asset resolves.

There is no root `package.json`, no `api/` folder and no `vercel.json`, so no platform
can mistake it for a Node project. Framework preset: **Other**. Build command: empty.
Output directory: empty. A `.vercelignore` keeps `backend/` out of the upload.

Records live in each visitor's browser. It is a complete working CRM for one person —
good for a demo, a sales link, or your own use.

### The backend — Railway, Render, Fly.io, a VM

`backend/` needs a writable disk (it runs PostgreSQL in-process), which serverless
platforms do not provide. Any container host works:

```bash
cd backend && npm install && npm start      # PORT and DB_PATH from the environment
```

Then point the static app at it, from anywhere, by adding one line to `index.html`:

```html
<meta name="anvaya-api" content="https://your-backend.up.railway.app">
```

Set `CORS_ORIGIN` on the backend to the site's exact origin, and the app switches to
shared records on first load. No rebuild, no config file, no framework detection.

### Install it as an app

The same URL installs as a real application — no app store, no signing, no separate
builds:

| Platform | How |
|---|---|
| Windows (Chrome, Edge) | Install icon in the address bar, or menu → Apps → Install this site |
| macOS (Chrome, Edge) | Same as Windows; in Safari, File → Open in Safari, then Share → Add to Dock |
| Android (Chrome) | Menu → Install app (an in-app banner offers it too) |
| iOS / iPadOS (Safari) | Share → Add to Home Screen (Chrome on iOS cannot install PWAs) |

It opens in its own window with its own icon, works offline once opened, and keeps your
records on the device. The **Install app** button in the header walks you through it.

See [`DEPLOY.md`](DEPLOY.md) for the step-by-step of each path, including moving to
Supabase Postgres.

---

## Responsive

One layout, three targets — no separate mobile app, no "view desktop site" fallback.

| | Phone (<=760px) | Tablet (761–1024px) | Desktop (>=1025px) |
|---|---|---|---|
| Navigation | off-canvas drawer + 5-slot bottom bar | drawer, rail when wide | fixed sidebar, collapsible to a rail |
| Tables | one card per record, each field labelled | full table | full table |
| Pipeline | swipeable columns, snap to one stage | 3–4 visible columns | all stages visible |
| Copilot | full screen | side panel | side panel |
| Search | icon in the header | icon in the header | full search field |

Details that make it usable on a phone rather than merely fitting: 38px minimum touch
targets, 16px inputs so iOS does not zoom on focus, `viewport-fit=cover` and
`env(safe-area-inset-*)` padding so the notch and home bar do not overlap content,
`100dvh` so the browser's address bar does not crop the layout, drawer scroll locking,
and drag-and-drop replaced by a stage picker in the deal sheet (HTML5 drag does not
exist on touch).

| | |
|---|---|
| ![Phone](docs/screenshots/phone-home.png) | ![Menu](docs/screenshots/phone-menu.png) |
| Home on a 390px phone | The drawer, with labels and install/theme/help |
| ![Phone leads](docs/screenshots/phone-leads.png) | ![Tablet](docs/screenshots/tablet-home.png) |
| Tables become labelled cards | Tablet: three stats across, drawer navigation |

## What V6 added

| Feature | Status |
|---|---|
| Two-factor authentication (TOTP + backup codes) | Working, 4 tests |
| PDF quotations, tax invoices and receipts | Working, 3 tests |
| Payments, part payments, refunds, credit notes, payment links | Working, 6 tests |
| Invoice numbering, GST split, overdue detection | Working, 5 tests |
| Navigation rebuilt to the seven-group structure, permission-aware | Working |

64 backend tests pass, including all 48 that covered V5 — the regression
evidence that the upgrade did not break the existing product. Read
`docs/V6-ASSESSMENT.md` for the audit and `docs/V6-RELEASE.md` for the feature
status, test report and migration guide. Manuals: `docs/USER-MANUAL.md`,
`docs/ADMIN-MANUAL.md`.

## Where this stands against the big five

The competitive gap list, answered honestly. "Built" means it works and is tested here;
"needs your credentials" means the code is finished but the provider side is yours.

| # | Gap | Status | Notes |
|---|---|---|---|
| 1 | Gmail/Outlook + calendar two-way sync | **Built, needs credentials** | OAuth flow, encrypted token storage, refresh, delta sync, de-duplication. Reading mail/events into activities works; sending is stubbed behind the same token. Set `GOOGLE_CLIENT_ID` / `MS_CLIENT_ID` + `ENCRYPTION_KEY`. |
| 2 | Visual kanban, drag and drop | **Built** | Drag between stages on desktop, tap-to-move on touch, keyboard move, audit entry and automations on every change. |
| 3 | Workflow automation builder | **Built (form-based)** | Trigger → conditions → actions → approval → run log. A node canvas is not built; the engine and logs are. |
| 4 | Web-to-lead + email-to-lead | **Built** | Public form endpoint with honeypot, rate limit and duplicate flag; embeddable snippet; HMAC-signed inbound email that matches an existing contact or creates a lead. |
| 5 | AI summaries + next-best-action | **Built** | Copilot over your records in two modes; per-deal next step on the deal sheet; every run logged. |
| 6 | Custom fields and layouts | **Built (fields)** | Admin-defined fields appear automatically on lead, contact, company, deal and ticket forms and are stored per record. Layout editor not built. |
| 7 | Roles + multi-currency | **Roles built, currency partial** | Nine role templates enforced in the API and in RLS. Currency is stored per deal; rollups convert at a stored rate — the FX admin screen is not built. |
| 8 | User-built reports and saved views | **Saved views built, builder partial** | Views persist per user and can be shared. Report builder is fixed widgets, not drag-your-own-metric. |
| 9 | Mobile offline read/update | **Partial** | The static edition is fully offline. The server edition caches the shell but queues no writes yet. |
| 10 | API + connectors + Zapier/Make | **Built** | REST API with scoped bearer keys, HMAC-signed outbound webhooks, OpenAPI document at `/api/openapi.json`. Zapier/Make consume these without a custom connector. |

## What is built

Working end to end: dashboard, leads (with one-click conversion into company + contact +
deal), contacts and companies, customer 360, multi-stage pipeline with drag and drop,
tasks, support tickets with SLA state, products, quotations, invoices, projects,
campaigns, a workflow engine (trigger → conditions → actions → approval → logs), reports,
settings with members and roles, the copilot, global search and a help panel.

Not built: field operations, the no-code builder, OAuth integrations, payment
processing, PDF generation, MFA. Those are listed as absent rather than shipped as dead
buttons.

## Two modes, one codebase

`data.js` probes `GET /api/health` once at boot.

- Answers `{ mode: "server" }` → the UI calls the real API. Multi-user, shared records,
  PostgreSQL with row level security, an append-only audit trail.
- No answer, or no server → `engine.js` serves the identical routes from `localStorage`.

The header chip tells you which one is live: *Live data* or *Saved in this browser*.
Nothing else in the interface changes, because nothing else knows the difference.

## Tests

```bash
cd backend && npm test      # 34 tests: API flows, tenant isolation, permissions, audit
```

The security tests are the ones worth reading: cross-tenant reads return 404, a
deliberately unscoped SQL query returns nothing, a read-only member is blocked at both
the API and the database, and audit rows cannot be forged.
