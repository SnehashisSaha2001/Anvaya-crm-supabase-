// The Supabase → local backup mirror, tested against a database built from the
// real supabase/anvaya-supabase.sql (PGlite standing in for Supabase's Postgres).

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { PGlite } from '@electric-sql/pglite';
import { runMirror } from '../scripts/supabase-mirror.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SQL = fs.readFileSync(path.join(HERE, '..', '..', 'supabase', 'anvaya-supabase.sql'), 'utf8')
  .replace("'you@yourcompany.com'", "'mirror@test.in'")
  .replace("'Your Company'", "'Mirror Co'")
  .replace("'your-company'", "'mirror-co'");

async function fakeSupabase() {
  const pg = new PGlite();
  await pg.waitReady;
  await pg.exec(`
    create schema if not exists auth;
    create or replace function auth.uid() returns uuid language sql stable as $$
      select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
    do $$ begin if not exists (select 1 from pg_roles where rolname='anon') then create role anon nologin; end if; end $$;
    do $$ begin if not exists (select 1 from pg_roles where rolname='authenticated') then create role authenticated nologin; end if; end $$;
    do $$ begin if not exists (select 1 from pg_roles where rolname='service_role') then create role service_role nologin; end if; end $$;
  `);
  await pg.exec(SQL);
  await pg.query(`insert into users (email, password_hash, full_name) values ('mirror@test.in','x','Mirror')`);
  await pg.exec(SQL);                         // second run creates the workspace
  const pool = {
    connect: async () => ({
      query: (s, p) => (p === undefined ? pg.query(s) : pg.query(s, p)),
      release: () => {}
    })
  };
  return { pg, pool };
}

const count = async (pg, t) => Number((await pg.query(`select count(*)::int n from ${t}`)).rows[0].n);

describe('supabase → local mirror', () => {
  test('copies every table, builds the local schema, and verifies counts', async () => {
    const { pg: remote, pool } = await fakeSupabase();
    const org = (await remote.query(`select id from organisations limit 1`)).rows[0].id;
    await remote.query(`insert into leads (org_id, name) values ($1,'Alpha Lead'),($1,'Beta Lead')`, [org]);

    const local = new PGlite(); await local.waitReady;
    const r = await runMirror(pool, local);

    assert.ok(r.tables >= 51, `expected the full schema, got ${r.tables} tables`);
    assert.equal(await count(local, 'organisations'), await count(remote, 'organisations'));
    assert.equal(await count(local, 'users'), 1);
    const names = (await local.query(`select name from leads order by name`)).rows.map((x) => x.name);
    assert.deepEqual(names, ['Alpha Lead', 'Beta Lead']);
    assert.equal(await count(local, 'roles'), await count(remote, 'roles'));
    assert.deepEqual(r.skipped, []);
  });

  test('a second run reflects edits and deletions made in Supabase', async () => {
    const { pg: remote, pool } = await fakeSupabase();
    const org = (await remote.query(`select id from organisations limit 1`)).rows[0].id;
    await remote.query(`insert into leads (org_id, name) values ($1,'Keep'),($1,'Remove')`, [org]);

    const local = new PGlite(); await local.waitReady;
    await runMirror(pool, local);
    await remote.query(`delete from leads where name = 'Remove'`);
    await remote.query(`update leads set name = 'Kept (edited)' where name = 'Keep'`);
    await runMirror(pool, local);

    const names = (await local.query(`select name from leads`)).rows.map((x) => x.name);
    assert.deepEqual(names, ['Kept (edited)']);
  });

  test('a failed run leaves the previous backup untouched', async () => {
    const { pg: remote, pool } = await fakeSupabase();
    const org = (await remote.query(`select id from organisations limit 1`)).rows[0].id;
    await remote.query(`insert into leads (org_id, name) values ($1,'Safe')`, [org]);

    const local = new PGlite(); await local.waitReady;
    await runMirror(pool, local);

    // A source that dies part-way through the second run.
    let calls = 0;
    const flaky = {
      connect: async () => {
        const c = await pool.connect();
        return {
          release: c.release,
          query: (s, p) => {
            if (/^fetch/.test(s) && ++calls > 3) return Promise.reject(new Error('connection reset'));
            return c.query(s, p);
          }
        };
      }
    };
    await remote.query(`insert into leads (org_id, name) values ($1,'Never arrives')`, [org]);
    await assert.rejects(runMirror(flaky, local), /connection reset/);

    const names = (await local.query(`select name from leads`)).rows.map((x) => x.name);
    assert.deepEqual(names, ['Safe'], 'the earlier backup must survive a failed run');
  });

  test('refuses to run as a role that row-level security would blind', async () => {
    const { pg: remote, pool } = await fakeSupabase();
    await remote.exec(`set role authenticated`);
    const local = new PGlite(); await local.waitReady;
    await assert.rejects(runMirror(pool, local), /cannot bypass row-level security/);
  });
});
