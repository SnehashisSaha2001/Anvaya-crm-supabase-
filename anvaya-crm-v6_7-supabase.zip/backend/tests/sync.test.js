// Two-way sync rules: pull merges, push replays, conflicts are never silent.

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import syncModule from '../../sync.js';
import idbModule from '../../idb.js';

const createSync = syncModule.create;
const memoryStore = idbModule.memory;

const TABLES = ['leads', 'deals'];

function makeApi({ rows = {}, failNetwork = false, record = null } = {}) {
  const calls = [];
  const api = async (path, opts = {}) => {
    calls.push({ path, opts });
    if (failNetwork) throw new TypeError('Failed to fetch');
    const listMatch = path.match(/^\/api\/(\w+)\?/);
    if (listMatch && !opts.method) return { data: rows[listMatch[1]] || [], total: (rows[listMatch[1]] || []).length };
    const oneMatch = path.match(/^\/api\/(\w+)\/([\w-]+)$/);
    if (oneMatch && !opts.method) return record || { id: oneMatch[2], updated_at: '2026-01-01T00:00:00Z' };
    if (opts.method === 'POST') return { id: 'srv-new', ...opts.body, updated_at: '2026-02-01T00:00:00Z' };
    if (opts.method === 'PATCH') return { id: oneMatch[2], ...opts.body, updated_at: '2026-02-01T00:00:00Z' };
    if (opts.method === 'DELETE') return { ok: true };
    return {};
  };
  api.calls = calls;
  return api;
}

describe('pull', () => {
  test('merges server rows in and remembers a cursor', async () => {
    const store = memoryStore();
    const api = makeApi({ rows: {
      leads: [{ id: 'l1', name: 'A', updated_at: '2026-01-02T00:00:00Z' }],
      deals: []
    } });
    const sync = createSync({ store, api, tables: TABLES });

    const out = await sync.pull();
    assert.equal(out.rows, 1);
    assert.equal((await store.get('leads', 'l1')).name, 'A');
    assert.equal(await store.meta('cursor:leads'), '2026-01-02T00:00:00Z');
  });

  test('a server delete removes the local row', async () => {
    const store = memoryStore();
    await store.put('leads', { id: 'l1', name: 'A', updated_at: '2026-01-01T00:00:00Z' });
    const api = makeApi({ rows: { leads: [{ id: 'l1', deleted_at: '2026-01-05T00:00:00Z', updated_at: '2026-01-05T00:00:00Z' }] } });
    const sync = createSync({ store, api, tables: ['leads'] });

    await sync.pull();
    assert.equal(await store.get('leads', 'l1'), null);
  });

  test('a local edit newer than the server survives the pull', async () => {
    const store = memoryStore();
    const sync = createSync({ store, api: makeApi({ rows: { leads: [] } }), tables: ['leads'] });
    await sync.save('leads', { id: 'l1', name: 'Local edit', updated_at: '2026-01-01T00:00:00Z' }, 'PATCH', '2026-01-01T00:00:00Z');

    // the server still holds the older version
    const api2 = makeApi({ rows: { leads: [{ id: 'l1', name: 'Server old', updated_at: '2026-01-01T00:00:00Z' }] } });
    const sync2 = createSync({ store, api: api2, tables: ['leads'] });
    await sync2.pull();

    const row = await store.get('leads', 'l1');
    assert.equal(row.name, 'Local edit');
    assert.equal(row._dirty, 1, 'still queued to go up');
  });

  test('a genuine conflict keeps the server row and files the local one', async () => {
    const store = memoryStore();
    const sync = createSync({ store, api: makeApi({ rows: { leads: [] } }), tables: ['leads'] });
    await sync.save('leads', { id: 'l1', name: 'Mine', updated_at: '2026-01-01T00:00:00Z' }, 'PATCH', '2026-01-01T00:00:00Z');

    // someone else changed the row after my edit was made
    const api2 = makeApi({ rows: { leads: [{ id: 'l1', name: 'Theirs', updated_at: '2026-03-01T00:00:00Z' }] } });
    const sync2 = createSync({ store, api: api2, tables: ['leads'] });
    const out = await sync2.pull();

    assert.equal(out.conflicts, 1);
    assert.equal((await store.get('leads', 'l1')).name, 'Theirs', 'server wins the record');
    const filed = await store.conflictList();
    assert.equal(filed.length, 1);
    assert.equal(filed[0].local.name, 'Mine', 'the local version is preserved, not lost');
    assert.equal(filed[0].server.name, 'Theirs');
  });
});

describe('push', () => {
  test('replays queued creates and updates in order', async () => {
    const store = memoryStore();
    const api = makeApi();
    const sync = createSync({ store, api, tables: TABLES });

    await sync.save('leads', { name: 'New lead' }, 'POST');
    await sync.save('leads', { id: 'l9', name: 'Edited' }, 'PATCH', '2026-01-01T00:00:00Z');

    const out = await sync.push();
    assert.equal(out.sent, 2);
    assert.equal(out.pending, 0);
    const methods = api.calls.filter(c => c.opts.method).map(c => c.opts.method);
    assert.deepEqual(methods, ['POST', 'PATCH']);
  });

  test('a queued edit is refused when the server moved on', async () => {
    const store = memoryStore();
    const sync = createSync({ store, api: makeApi(), tables: ['leads'] });
    await sync.save('leads', { id: 'l1', name: 'Mine' }, 'PATCH', '2026-01-01T00:00:00Z');

    // the record on the server is newer than the edit's base
    const api2 = makeApi({ record: { id: 'l1', name: 'Theirs', updated_at: '2026-04-01T00:00:00Z' } });
    const sync2 = createSync({ store, api: api2, tables: ['leads'] });
    const out = await sync2.push();

    assert.equal(out.conflicts, 1);
    assert.equal(out.sent, 0);
    assert.equal((await store.get('leads', 'l1')).name, 'Theirs');
    assert.equal((await store.conflictList()).length, 1);
  });

  test('a network failure stops the queue without losing it', async () => {
    const store = memoryStore();
    const sync = createSync({ store, api: makeApi(), tables: ['leads'] });
    await sync.save('leads', { name: 'A' }, 'POST');
    await sync.save('leads', { name: 'B' }, 'POST');

    const offline = createSync({ store, api: makeApi({ failNetwork: true }), tables: ['leads'] });
    const out = await offline.push();
    assert.equal(out.sent, 0);
    assert.equal(out.pending, 2, 'both stay queued for later');
  });

  test('a refused change is dropped rather than retried forever', async () => {
    const store = memoryStore();
    const sync = createSync({ store, api: makeApi(), tables: ['leads'] });
    await sync.save('leads', { name: 'Bad' }, 'POST');

    const refusing = async (path, opts = {}) => {
      if (opts.method) { const e = new Error('forbidden'); e.status = 403; throw e; }
      return { id: 'x', updated_at: '2026-01-01T00:00:00Z' };
    };
    const s2 = createSync({ store, api: refusing, tables: ['leads'] });
    const out = await s2.push();
    assert.equal(out.failed, 1);
    assert.equal(out.pending, 0);
  });
});

describe('syncAll', () => {
  test('pushes then pulls, and reports both', async () => {
    const store = memoryStore();
    const api = makeApi({ rows: { leads: [{ id: 'remote1', name: 'From another device', updated_at: '2026-05-01T00:00:00Z' }] } });
    const sync = createSync({ store, api, tables: ['leads'] });
    await sync.save('leads', { name: 'Mine' }, 'POST');

    const out = await sync.syncAll();
    assert.equal(out.pushed.sent, 1);
    assert.equal(out.pulled.rows, 1);
    assert.equal((await store.get('leads', 'remote1')).name, 'From another device',
      'a change made on another device arrives');
  });
});
