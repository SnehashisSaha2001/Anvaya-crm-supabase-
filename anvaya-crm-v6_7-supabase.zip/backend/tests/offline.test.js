// Local storage as a backup, not a second database: the cache and outbox rules.

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { createOffline } from '../../offline.js';

function memStorage() {
  const m = new Map();
  return {
    getItem: (k) => (m.has(k) ? m.get(k) : null),
    setItem: (k, v) => m.set(k, v),
    removeItem: (k) => m.delete(k)
  };
}
const make = (max = 400) => createOffline({ storage: memStorage(), maxCacheEntries: max });

describe('offline cache', () => {
  test('stores a read and returns it later', () => {
    const off = make();
    off.cachePut('/api/leads', { data: [1] });
    assert.deepEqual(off.cacheGet('/api/leads'), { data: [1] });
    assert.equal(off.cacheGet('/api/never-opened'), null);
  });

  test('evicts the oldest entries instead of growing without limit', () => {
    const off = make(3);
    off.cachePut('/a', 1); off.cachePut('/b', 2); off.cachePut('/c', 3); off.cachePut('/d', 4);
    assert.equal(off.cacheGet('/d'), 4);
    assert.ok(off.cacheGet('/a') === null, 'the oldest entry is dropped');
  });
});

describe('offline outbox', () => {
  test('queues in order and reports what is waiting', () => {
    const off = make();
    const a = off.enqueue({ path: '/api/leads', method: 'POST', body: { name: 'A' } });
    off.enqueue({ path: '/api/leads/1', method: 'PATCH', body: { name: 'B' } });
    assert.equal(off.pending().length, 2);
    assert.equal(off.pending()[0].id, a.id);
  });

  test('a change interrupted mid-send is held back, never replayed', () => {
    const off = make();
    const a = off.enqueue({ path: '/api/leads', method: 'POST', body: {} });
    off.markSending(a.id);
    const uncertain = off.markUncertain();
    assert.equal(uncertain.length, 1);
    assert.equal(off.pending().length, 0, 'uncertain items are not in the pending queue');
    assert.equal(off.uncertain()[0].id, a.id);
  });

  test('replay resolves each item: sent, conflicted, refused or retried', async () => {
    const off = make();
    const ok = off.enqueue({ path: '/api/leads', method: 'POST', body: {} });
    const conflict = off.enqueue({ path: '/api/leads/2', method: 'PATCH', body: {}, baseUpdatedAt: '2026-01-01T00:00:00Z' });
    const refused = off.enqueue({ path: '/api/leads/3', method: 'DELETE' });

    const result = await off.flush(async (item) => {
      if (item.id === conflict.id) { const e = new Error('changed'); e.status = 409; throw e; }
      if (item.id === refused.id) { const e = new Error('forbidden'); e.status = 403; throw e; }
      return { id: 'srv1' };
    });

    assert.equal(result.done.length, 1);
    assert.equal(result.conflicts.length, 1);
    assert.equal(result.failed.length, 1);
    assert.equal(off.outbox().length, 0);
    void ok;
  });

  test('a network failure stops the queue and keeps everything', async () => {
    const off = make();
    off.enqueue({ path: '/api/a', method: 'POST', body: {} });
    off.enqueue({ path: '/api/b', method: 'POST', body: {} });
    const result = await off.flush(async () => { throw new TypeError('Failed to fetch'); });
    assert.equal(result.failed.length, 1, 'stops at the first network failure');
    assert.equal(off.pending().length, 2, 'nothing is lost');
  });
});
