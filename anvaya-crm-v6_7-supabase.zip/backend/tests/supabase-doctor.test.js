// The connection doctor must be right about both outcomes: a database built from
// anvaya-supabase.sql passes every check, and one whose grants went to the wrong
// role fails the check that exists to catch exactly that.

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { PGlite } from '@electric-sql/pglite';
import { runChecks } from '../scripts/check-supabase.mjs';

const quiet = { log: () => {} };

async function buildDb(sqlText) {
  const pg = new PGlite();
  await pg.waitReady;
  await pg.exec(`
    create schema if not exists auth;
    create or replace function auth.uid() returns uuid language sql stable as $$
      select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
    do $$ begin if not exists (select 1 from pg_roles where rolname='anon') then create role anon nologin; end if; end $$;
    do $$ begin if not exists (select 1 from pg_roles where rolname='authenticated') then create role authenticated nologin; end if; end $$;
    do $$ begin if not exists (select 1 from pg_roles where rolname='service_role') then create role service_role nologin; end if; end $$;
  `);
  if (sqlText) await pg.exec(sqlText);
  return { pg, client: { query: (s, p) => (p === undefined ? pg.query(s) : pg.query(s, p)) } };
}

function supabaseSql(email = 'doc@test.in', org = 'Doc Co', slug = 'doc-co') {
  return fs.readFileSync('/scratch/work/anvaya3/supabase/anvaya-supabase.sql', 'utf8')
    .replace("'you@yourcompany.com'", `'${email}'`)
    .replace("'Your Company'", `'${org}'`)
    .replace("'your-company'", `'${slug}'`);
}

describe('supabase connection doctor', () => {
  test('passes on a database built from the setup file, once a user exists', async () => {
    const { pg, client } = await buildDb(supabaseSql());
    await pg.query(`insert into users (email, password_hash, full_name) values ('doc@test.in','x','Doc')`);
    await pg.exec(supabaseSql());                    // second run creates the workspace

    const results = await runChecks(client, quiet);
    const failed = results.filter(r => !r.pass);
    assert.deepEqual(failed.map(r => r.name), [], `unexpected failures: ${JSON.stringify(failed)}`);
    assert.ok(results.length >= 6);
  });

  test('fails the grants check when privileges went to the wrong role', async () => {
    const { pg, client } = await buildDb(supabaseSql());
    await pg.query(`insert into users (email, password_hash, full_name) values ('doc@test.in','x','Doc')`);
    await pg.exec(supabaseSql());
    // simulate the earlier bundle: grants on app_user, nothing for authenticated
    await pg.exec(`revoke all on all tables in schema public from authenticated;`);

    const results = await runChecks(client, quiet);
    const grants = results.find(r => r.name.includes('table privileges'));
    assert.equal(grants.pass, false);
    assert.match(grants.fix, /GRANT block/i);
  });

  test('fails the seed check on an empty database', async () => {
    const { client } = await buildDb(null);
    const results = await runChecks(client, quiet);
    const schema = results.find(r => r.name.includes('schema present'));
    assert.equal(schema.pass, false);
    assert.match(schema.fix, /anvaya-supabase\.sql/);
  });
});
