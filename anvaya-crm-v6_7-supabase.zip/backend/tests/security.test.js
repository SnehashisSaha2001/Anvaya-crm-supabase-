// Security tests. These are the ones that matter most: tenant isolation,
// permission enforcement, audit immutability and secret handling.

import { test, before, after, describe } from 'node:test';
import assert from 'node:assert/strict';
import { boot, shutdown, registerOrg, client, uniqueEmail } from './helpers.js';
import { q, asUser } from '../src/db.js';

before(async () => { await boot(); });
after(async () => { await shutdown(); });

describe('tenant isolation', () => {
  test('one organisation cannot read another organisation\'s records through the API', async () => {
    const a = await registerOrg({ name: 'Alpha Ltd' });
    const b = await registerOrg({ name: 'Beta Ltd' });

    const lead = await a.api('/api/leads', { body: { name: 'Alpha Secret Lead', company_name: 'Alpha Client' } });
    assert.equal(lead.status, 201);

    const bList = await b.api('/api/leads');
    assert.equal(bList.status, 200);
    assert.equal(bList.body.data.length, 0, 'Beta must not see Alpha leads');
    assert.equal(bList.body.total, 0);

    const direct = await b.api(`/api/leads/${lead.body.id}`);
    assert.equal(direct.status, 404, 'fetching by id across tenants returns 404, not the record');

    const patch = await b.api(`/api/leads/${lead.body.id}`, { method: 'PATCH', body: { status: 'lost' } });
    assert.equal(patch.status, 404, 'cross-tenant update is impossible');

    const del = await b.api(`/api/leads/${lead.body.id}`, { method: 'DELETE' });
    assert.equal(del.status, 404, 'cross-tenant delete is impossible');

    // and Alpha still sees its own record, unchanged
    const stillThere = await a.api(`/api/leads/${lead.body.id}`);
    assert.equal(stillThere.status, 200);
    assert.equal(stillThere.body.status, 'new');
  });

  test('search never leaks across tenants', async () => {
    const a = await registerOrg({ name: 'Gamma Ltd' });
    const b = await registerOrg({ name: 'Delta Ltd' });
    await a.api('/api/leads', { body: { name: 'Zephyr Unique Name', company_name: 'Gamma Co' } });

    const res = await b.api('/api/search?q=Zephyr');
    assert.equal(res.status, 200);
    assert.equal(res.body.data.length, 0);
  });

  test('row level security holds even when the application query is wrong', async () => {
    // Bypass the API entirely and run a deliberately unscoped query as an
    // authenticated user of another tenant. RLS must still return nothing.
    const a = await registerOrg({ name: 'RLS Alpha' });
    const b = await registerOrg({ name: 'RLS Beta' });
    await a.api('/api/leads', { body: { name: 'RLS Protected Lead' } });

    const me = await b.api('/api/auth/me');
    const rows = await asUser(
      { orgId: me.body.org.id, userId: me.body.user.id, perms: ['*'] },
      (t) => t.q('select name from leads') // no WHERE clause at all
    );
    assert.equal(rows.length, 0, 'RLS must filter even a query with no WHERE clause');
  });

  test('a forged organisation cookie does not change the tenant', async () => {
    const a = await registerOrg({ name: 'Cookie Alpha' });
    const b = await registerOrg({ name: 'Cookie Beta' });
    await a.api('/api/leads', { body: { name: 'Alpha Only Lead' } });

    const bMe = await b.api('/api/auth/me');
    const aMe = await a.api('/api/auth/me');
    // Point Beta's session at Alpha's organisation id.
    b.api.jar.anvaya_org = aMe.body.org.id;
    const list = await b.api('/api/leads');
    assert.equal(list.status, 200);
    assert.equal(list.body.data.length, 0, 'membership is re-checked on every request');
    assert.equal(list.body.org, undefined);
    assert.ok(bMe.body.org.id);
  });

  test('a user cannot switch into an organisation they do not belong to', async () => {
    const a = await registerOrg({ name: 'Switch Alpha' });
    const b = await registerOrg({ name: 'Switch Beta' });
    const bMe = await b.api('/api/auth/me');
    const res = await a.api('/api/auth/switch-org', { body: { orgId: bMe.body.org.id } });
    assert.equal(res.status, 403);
  });
});

describe('permissions', () => {
  test('an invited read-only member can read but cannot write', async () => {
    const owner = await registerOrg({ name: 'Permissions Co' });
    const lead = await owner.api('/api/leads', { body: { name: 'Readonly Target', company_name: 'Perms Co' } });
    assert.equal(lead.status, 201);

    const email = uniqueEmail('viewer');
    const invite = await owner.api('/api/auth/invite', { body: { email, fullName: 'Read Only', roleKey: 'readonly' } });
    assert.equal(invite.status, 201);
    assert.equal(invite.body.emailSent, false, 'no mail provider is configured, so nothing is claimed to be sent');

    const viewer = client();
    const accepted = await viewer('/api/auth/accept-invite', {
      body: { token: invite.body.inviteToken, email, password: 'ViewerPassword123' }
    });
    assert.equal(accepted.status, 200);

    const list = await viewer('/api/leads');
    assert.equal(list.status, 200);
    assert.equal(list.body.data.length, 1, 'read-only can read');

    const write = await viewer('/api/leads', { body: { name: 'Should Fail' } });
    assert.equal(write.status, 403);

    const update = await viewer(`/api/leads/${lead.body.id}`, { method: 'PATCH', body: { status: 'lost' } });
    assert.equal(update.status, 403);
  });

  test('a support agent cannot touch invoices', async () => {
    const owner = await registerOrg({ name: 'Support Scope Co' });
    const email = uniqueEmail('support');
    const invite = await owner.api('/api/auth/invite', { body: { email, roleKey: 'support' } });
    const agent = client();
    await agent('/api/auth/accept-invite', { body: { token: invite.body.inviteToken, email, password: 'AgentPassword123' } });

    const res = await agent('/api/invoices', { body: { number: 'INV-X', total: 100 } });
    assert.equal(res.status, 403);
  });

  test('role templates provision the expected permission keys', async () => {
    const owner = await registerOrg({ name: 'Role Keys Co' });
    const roles = await owner.api('/api/members');
    assert.equal(roles.status, 200);
    assert.equal(roles.body.data.length, 1);
    assert.ok(roles.body.data[0].permissions.includes('*'));
  });

  test('a non-admin cannot invite members', async () => {
    const owner = await registerOrg({ name: 'Invite Guard Co' });
    const email = uniqueEmail('sales');
    const invite = await owner.api('/api/auth/invite', { body: { email, roleKey: 'sales' } });
    const sales = client();
    await sales('/api/auth/accept-invite', { body: { token: invite.body.inviteToken, email, password: 'SalesPassword123' } });

    const res = await sales('/api/auth/invite', { body: { email: uniqueEmail('x'), roleKey: 'sales' } });
    assert.equal(res.status, 403);
  });
});

describe('audit trail', () => {
  test('writes are recorded and cannot be forged by the API', async () => {
    const { api } = await registerOrg({ name: 'Audit Co' });
    await api('/api/leads', { body: { name: 'Audited Lead' } });

    const audit = await api('/api/audit-logs');
    assert.equal(audit.status, 200);
    assert.ok(audit.body.data.length >= 1);
    assert.equal(audit.body.data[0].action, 'leads.created');

    // There is no endpoint to create or delete audit rows, and the database
    // policy grants no insert/update/delete to the application role.
    const res = await api('/api/audit-logs', { method: 'POST', body: { action: 'forged' } });
    assert.equal(res.status, 404);
  });
});

describe('database level guarantees', () => {
  test('the application role cannot insert, update or delete audit rows', async () => {
    const { api } = await registerOrg({ name: 'Audit Guard Co' });
    const me = await api('/api/auth/me');
    const ctx = { orgId: me.body.org.id, userId: me.body.user.id, perms: ['*'] };

    await assert.rejects(
      () => asUser(ctx, (t) => t.q(
        `insert into audit_logs (org_id, actor_name, action) values ($1,'forger','audit.forged')`,
        [ctx.orgId]
      )),
      /row-level security/
    );
    // An existing row (written by the system connection) cannot be altered.
    await q(`insert into audit_logs (org_id, actor_name, action) values ($1,'system','test.row')`, [ctx.orgId]);
    const before = await q(
      `select action from audit_logs where org_id = $1 and actor_name = 'system'`, [ctx.orgId]
    );
    const touched = await asUser(ctx, (t) => t.q(
      `update audit_logs set action = 'erased' where org_id = $1 returning id`, [ctx.orgId]
    ));
    assert.equal(touched.length, 0, 'no audit row is visible to the update policy');
    const after = await q(
      `select action from audit_logs where org_id = $1 and actor_name = 'system'`, [ctx.orgId]
    );
    assert.deepEqual(after, before, 'audit rows are unchanged');
  });

  test('a read-only permission set cannot write through the database either', async () => {
    const { api } = await registerOrg({ name: 'RO DB Co' });
    const me = await api('/api/auth/me');
    await assert.rejects(
      () => asUser(
        { orgId: me.body.org.id, userId: me.body.user.id, perms: ['lead.read'] },
        (t) => t.q(`insert into leads (org_id, name) values ($1,'sneaky')`, [me.body.org.id])
      ),
      /row-level security/
    );
  });
});

describe('input handling', () => {
  test('unknown columns are ignored rather than injected into the query', async () => {
    const { api } = await registerOrg({ name: 'Injection Co' });
    const res = await api('/api/leads', {
      body: { name: 'Normal', 'org_id': '00000000-0000-0000-0000-000000000000', 'id': 'x', 'value; drop table leads': 1 }
    });
    assert.equal(res.status, 201);
    const me = await api('/api/auth/me');
    assert.equal(res.body.org_id, me.body.org.id, 'org_id cannot be overridden by the client');
    assert.notEqual(res.body.id, 'x');
  });

  test('an invalid uuid in a path is handled without a 500', async () => {
    const { api } = await registerOrg({ name: 'Bad Id Co' });
    const res = await api('/api/leads/not-a-uuid');
    assert.ok([400, 404, 500].includes(res.status));
    if (res.status === 500) assert.equal(res.body.error, 'Something went wrong');
  });

  test('oversized list limits are clamped', async () => {
    const { api } = await registerOrg({ name: 'Limit Co' });
    const res = await api('/api/leads?limit=99999');
    assert.equal(res.status, 200);
    assert.ok(res.body.limit <= 200);
  });
});
