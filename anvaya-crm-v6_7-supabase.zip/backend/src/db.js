// Database access layer.
//
// Two connection modes:
//   system  — the migration/auth connection. Bypasses RLS by design.
//   user    — request context: SET ROLE app_user plus org, user and permission
//             settings, so row level security applies to every statement.
//
// Two drivers, chosen by environment:
//   DATABASE_URL set  → a real PostgreSQL server (Supabase, RDS, Neon) via `pg`
//   otherwise         → PGlite, PostgreSQL 16 compiled to WASM, in-process
//
// Both expose the same three operations (query, exec, transaction), so every
// other module in the backend is driver-agnostic.

import { PGlite } from '@electric-sql/pglite';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Anchor paths to the package, not the shell's working directory, so the
// server starts correctly whether it is run from backend/ or the repo root.
const PKG_ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');

let client;

/* ---------------------------------------------------------------- drivers -- */
/** The role a request runs as, so RLS applies. Supabase calls it authenticated. */
const USER_ROLE = process.env.DB_USER_ROLE
  || (process.env.DATABASE_URL || process.env.PG_SHIM === '1' ? 'authenticated' : 'app_user');

function pgliteAdapter(c) {
  return {
    driver: 'pglite',
    query: (sql, params) => c.query(sql, params),
    exec: (sql) => c.exec(sql),
    transaction: (fn) => c.transaction(fn),
    close: () => c.close()
  };
}

function pgAdapter(pool) {
  return {
    driver: 'pg',
    query: (sql, params) => pool.query(sql, params),
    // No parameters → pg uses the simple protocol, which allows several
    // statements in one call. Migrations rely on that.
    exec: (sql) => pool.query(sql),
    async transaction(fn) {
      const conn = await pool.connect();
      try {
        await conn.query('begin');
        const out = await fn({
          query: (sql, params) => conn.query(sql, params),
          exec: (sql) => conn.query(sql)
        });
        await conn.query('commit');
        return out;
      } catch (err) {
        try { await conn.query('rollback'); } catch { /* connection already gone */ }
        throw err;
      } finally {
        conn.release();
      }
    },
    close: () => pool.end()
  };
}

export async function initDb() {
  if (client) return client;

  const remote = process.env.DATABASE_URL || process.env.PG_SHIM === '1';
  if (remote) {
    // `pg` is imported only when it is actually used, so a local install that
    // never talks to a server does not need the dependency resolved.
    const { Pool } = process.env.PG_SHIM === '1'
      ? await import('../tests/pg-shim.mjs')
      : await import('pg');
    const pool = new Pool({
      connectionString: process.env.DATABASE_URL,
      max: Number(process.env.DB_POOL_SIZE || 5),
      ssl: process.env.DATABASE_SSL === '0' ? false : { rejectUnauthorized: false }
    });
    await pool.query('select 1');
    client = pgAdapter(pool);
    return client;
  }

  const DATA_DIR = process.env.DB_PATH || path.join(PKG_ROOT, '.data', 'anvaya');
  const pg = process.env.DB_MEMORY === '1'
    ? new PGlite()
    : (fs.mkdirSync(path.dirname(DATA_DIR), { recursive: true }), new PGlite(DATA_DIR));
  await pg.waitReady;
  client = pgliteAdapter(pg);
  return client;
}

export function db() {
  if (!client) throw new Error('initDb() must be awaited before db()');
  return client;
}

/** Every entry point awaits this, so callers never have to remember. */
async function ready() {
  if (!client) await initDb();
  return client;
}

/** System query — bypasses RLS. Only for auth, migrations and audit writes. */
export async function q(sql, params = []) {
  await ready();
  const res = await db().query(sql, params);
  return res.rows;
}

export async function one(sql, params = []) {
  const rows = await q(sql, params);
  return rows[0] || null;
}

/** System transaction. */
export async function tx(fn) {
  await ready();
  return db().transaction(async (t) => fn({
    q: async (sql, params = []) => (await t.query(sql, params)).rows,
    one: async (sql, params = []) => (await t.query(sql, params)).rows[0] || null
  }));
}

/**
 * Run a callback inside a transaction acting as a given user.
 * ctx = { orgId, userId, perms: string[] }
 */
export async function asUser(ctx, fn) {
  if (!ctx || !ctx.orgId || !ctx.userId) throw new Error('asUser requires orgId and userId');
  const perms = (ctx.perms || []).join(',');
  await ready();
  return db().transaction(async (t) => {
    await t.query(`set local role ${USER_ROLE}`);
    await t.query(`select set_config('app.org_id', $1, true)`, [ctx.orgId]);
    await t.query(`select set_config('app.user_id', $1, true)`, [ctx.userId]);
    await t.query(`select set_config('app.perms', $1, true)`, [perms]);
    return fn({
      q: async (sql, params = []) => (await t.query(sql, params)).rows,
      one: async (sql, params = []) => (await t.query(sql, params)).rows[0] || null,
      exec: async (sql) => t.exec(sql)
    });
  });
}

export function driver() {
  return client ? client.driver : null;
}

export async function closeDb() {
  if (client && client.close) await client.close();
  client = null;
}

export async function migrate(dir = path.join(PKG_ROOT, 'db', 'migrations')) {
  await ready();
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.sql')).sort();
  for (const file of files) {
    const sql = fs.readFileSync(path.join(dir, file), 'utf8');
    try {
      await db().exec(sql);
    } catch (err) {
      throw new Error(`Migration ${file} failed: ${err.message}`);
    }
  }
  return files;
}
