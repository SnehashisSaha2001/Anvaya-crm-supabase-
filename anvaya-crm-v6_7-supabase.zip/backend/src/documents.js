// ============================================================================
// Documents: numbering, totals, PDF rendering and version history.
//
// Every PDF is generated from the live record plus the organisation's branding.
// An issued document is also snapshotted, so a reprint later shows what the
// customer received rather than today's edited figures.
// ============================================================================

import PDFDocument from 'pdfkit';
import { q, one, asUser } from './db.js';
import { requireAuth, requirePerm } from './auth.js';
import { writeAudit } from './audit.js';

const DEFAULT_PREFIX = { quotation: 'QTN', invoice: 'INV', receipt: 'RCT', credit_note: 'CRN', proposal: 'PRP' };

export function money(n, currency = 'INR') {
  const v = Number(n || 0);
  const s = v.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return currency === 'INR' ? `Rs. ${s}` : `${currency} ${s}`;
}

/**
 * Line-level totals. Tax is grouped by rate so a mixed-rate invoice still
 * reports one CGST/SGST/IGST pair per rate, which is what a GST invoice needs.
 */
export function computeTotals(items, { discount = 0, taxMode = 'cgst_sgst', currency = 'INR' } = {}) {
  const lines = (items || []).map((it, i) => {
    const qty = Number(it.quantity ?? it.qty ?? 1);
    const rate = Number(it.unit_price ?? it.rate ?? 0);
    const lineDiscount = Number(it.discount || 0);
    const gross = qty * rate;
    const taxable = Math.max(gross - lineDiscount, 0);
    const taxRate = Number(it.tax_rate ?? 0);
    return {
      position: i + 1,
      description: it.description || it.name || 'Item',
      quantity: qty,
      unit_price: rate,
      discount: lineDiscount,
      tax_rate: taxRate,
      taxable,
      tax: Math.round(taxable * taxRate) / 100
    };
  });

  const grossSubtotal = lines.reduce((a, l) => a + l.quantity * l.unit_price, 0);
  const lineDiscounts = lines.reduce((a, l) => a + l.discount, 0);
  const orderDiscount = Math.max(Number(discount || 0), 0);
  const discountTotal = lineDiscounts + orderDiscount;
  const subtotal = grossSubtotal - lineDiscounts;

  // Spread an order-level discount proportionally so tax stays correct.
  const factor = subtotal > 0 ? Math.max(subtotal - orderDiscount, 0) / subtotal : 1;
  const byRate = new Map();
  for (const l of lines) {
    const taxable = Math.round(l.taxable * factor * 100) / 100;
    l.taxable = taxable;
    l.tax = Math.round(taxable * l.tax_rate) / 100;
    byRate.set(l.tax_rate, Math.round(((byRate.get(l.tax_rate) || 0) + l.tax) * 100) / 100);
  }

  const taxTotal = [...byRate.values()].reduce((a, b) => a + b, 0);
  const taxBreakup = [...byRate.entries()]
    .filter(([rate]) => rate > 0)
    .map(([rate, amount]) => taxMode === 'igst'
      ? { label: `IGST ${rate}%`, amount }
      : { label: `CGST ${rate / 2}%`, amount: Math.round((amount / 2) * 100) / 100 });

  if (taxMode !== 'igst') {
    const sgst = [...byRate.entries()].filter(([rate]) => rate > 0)
      .map(([rate, amount]) => ({ label: `SGST ${rate / 2}%`, amount: Math.round((amount / 2) * 100) / 100 }));
    taxBreakup.push(...sgst);
  }

  const total = Math.round((subtotal - orderDiscount + taxTotal) * 100) / 100;
  return {
    lines, subtotal: Math.round(subtotal * 100) / 100, discount_total: Math.round(discountTotal * 100) / 100,
    tax_total: Math.round(taxTotal * 100) / 100, total, tax_breakup: taxBreakup, currency
  };
}

/** Allocate the next number for a document type, atomically. */
export async function nextNumber(ctx, docType) {
  const prefix = DEFAULT_PREFIX[docType] || 'DOC';
  return asUser(ctx, async (t) => {
    const row = await t.one(
      `insert into document_sequences (org_id, doc_type, prefix, next_number)
       values ($1,$2,$3,2)
       on conflict (org_id, doc_type) do update set next_number = document_sequences.next_number + 1
       returning prefix, next_number, padding`,
      [ctx.orgId, docType, prefix]
    );
    const seq = row.next_number - 1;
    const year = new Date().getFullYear();
    return `${row.prefix}-${year}-${String(seq).padStart(row.padding, '0')}`;
  });
}

/* ------------------------------------------------------------------- PDFs -- */
const INK = '#12211D';
const MUTED = '#5A625F';
const RULE = '#D8D6CE';
const JADE = '#0E5F4C';

function drawHeader(doc, branding, title, meta) {
  const left = doc.page.margins.left;
  const right = doc.page.width - doc.page.margins.right;
  let y = 50;

  doc.fillColor(JADE).rect(0, 0, doc.page.width, 8).fill();

  doc.fillColor(INK).font('Helvetica-Bold').fontSize(17)
    .text(branding.legalName || branding.name || 'Your company', left, y, { width: 320 });
  y = doc.y + 4;
  doc.font('Helvetica').fontSize(9).fillColor(MUTED);
  for (const line of [branding.address1, branding.address2, branding.city, branding.phone, branding.email, branding.website]) {
    if (line) { doc.text(line, left, y, { width: 300 }); y = doc.y + 1; }
  }
  if (branding.gstin) { doc.text(`GSTIN: ${branding.gstin}`, left, y); y = doc.y + 1; }

  doc.font('Helvetica-Bold').fontSize(20).fillColor(INK)
    .text(title, left, 50, { width: right - left, align: 'right' });
  doc.font('Helvetica').fontSize(9).fillColor(MUTED);
  let my = 78;
  for (const [k, v] of meta) {
    if (!v) continue;
    doc.text(`${k}: ${v}`, left, my, { width: right - left, align: 'right' });
    my = doc.y + 1;
  }

  const lineY = Math.max(y, my) + 12;
  doc.moveTo(left, lineY).lineTo(right, lineY).strokeColor(RULE).lineWidth(1).stroke();
  return lineY + 18;
}

function drawParties(doc, y, customer, extra) {
  const left = doc.page.margins.left;
  const colW = (doc.page.width - doc.page.margins.left - doc.page.margins.right) / 2 - 10;

  doc.font('Helvetica-Bold').fontSize(8).fillColor(MUTED).text('BILL TO', left, y);
  doc.font('Helvetica-Bold').fontSize(11).fillColor(INK).text(customer.name || 'Customer', left, y + 13, { width: colW });
  doc.font('Helvetica').fontSize(9).fillColor(MUTED);
  let cy = doc.y + 2;
  for (const line of [customer.company, customer.address, customer.email, customer.phone, customer.gstin]) {
    if (line) { doc.text(line, left, cy, { width: colW }); cy = doc.y + 1; }
  }

  if (extra && extra.length) {
    const rx = left + colW + 20;
    doc.font('Helvetica-Bold').fontSize(8).fillColor(MUTED).text('DETAILS', rx, y);
    doc.font('Helvetica').fontSize(9);
    let ry = y + 13;
    for (const [k, v] of extra) {
      if (!v) continue;
      doc.fillColor(MUTED).text(k, rx, ry, { width: 90, continued: true });
      doc.fillColor(INK).text(String(v), { width: colW - 90 });
      ry = doc.y + 1;
    }
    cy = Math.max(cy, ry);
  }
  return cy + 18;
}

function drawItems(doc, y, lines, currency) {
  const left = doc.page.margins.left;
  const right = doc.page.width - doc.page.margins.right;
  const widths = [24, right - left - 24 - 60 - 70 - 80, 60, 70, 80];
  const headers = ['#', 'Description', 'Qty', 'Rate', 'Amount'];

  doc.rect(left, y, right - left, 20).fillColor('#E9E9EA').fill();
  doc.fillColor(INK).font('Helvetica-Bold').fontSize(8.5);
  let x = left + 4;
  headers.forEach((h, i) => {
    doc.text(h, x, y + 6, { width: widths[i], align: i >= 2 ? 'right' : 'left' });
    x += widths[i];
  });
  y += 20;

  doc.font('Helvetica').fontSize(9).fillColor(INK);
  for (const l of lines) {
    const rowH = 18;
    if (y + rowH > doc.page.height - doc.page.margins.bottom - 120) {
      doc.addPage();
      y = doc.page.margins.top;
    }
    x = left + 4;
    const cells = [String(l.position), l.description, String(l.quantity), money(l.unit_price, currency), money(l.taxable, currency)];
    cells.forEach((c, i) => {
      doc.fillColor(i === 1 ? INK : MUTED)
        .text(c, x, y + 5, { width: widths[i], align: i >= 2 ? 'right' : 'left', lineBreak: i === 1 });
      x += widths[i];
    });
    doc.moveTo(left, y + rowH).lineTo(right, y + rowH).strokeColor(RULE).lineWidth(0.5).stroke();
    y += rowH;
  }
  return y + 14;
}

function drawTotals(doc, y, totals, currency) {
  const right = doc.page.width - doc.page.margins.right;
  const boxW = 240;
  const x = right - boxW;
  let ty = y;

  const row = (label, value, bold = false) => {
    doc.font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(bold ? 11 : 9.5)
      .fillColor(bold ? INK : MUTED)
      .text(label, x, ty, { width: boxW * 0.55 })
      .text(value, x + boxW * 0.55, ty, { width: boxW * 0.45, align: 'right' });
    ty = doc.y + 3;
  };

  row('Subtotal', money(totals.subtotal, currency));
  if (totals.discount_total) row('Discount', `- ${money(totals.discount_total, currency)}`);
  for (const t of totals.tax_breakup || []) row(t.label, money(t.amount, currency));

  doc.moveTo(x, ty + 2).lineTo(right, ty + 2).strokeColor(RULE).stroke();
  ty += 10;
  row('Total', money(totals.total, currency), true);
  return ty;
}

function drawFooter(doc, branding, note) {
  const left = doc.page.margins.left;
  const right = doc.page.width - doc.page.margins.right;
  let y = doc.page.height - doc.page.margins.bottom - 60;
  doc.moveTo(left, y).lineTo(right, y).strokeColor(RULE).stroke();
  y += 8;
  doc.font('Helvetica').fontSize(8).fillColor(MUTED);
  if (branding.terms) doc.text(branding.terms, left, y, { width: right - left });
  if (branding.bank) doc.text(branding.bank, left, doc.y + 3, { width: right - left });
  if (note) doc.text(note, left, doc.y + 3, { width: right - left });
  doc.fontSize(7.5).fillColor('#8A938F')
    .text('Generated by Anvaya CRM', left, doc.page.height - doc.page.margins.bottom + 6, { width: right - left, align: 'center' });
}

function renderPdf(render) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margin: 50, bufferPages: true });
    const chunks = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);
    try { render(doc); doc.end(); } catch (err) { reject(err); }
  });
}

export function quotationPdf({ branding, quotation, lines, totals, customer }) {
  return renderPdf((doc) => {
    let y = drawHeader(doc, branding, 'QUOTATION', [
      ['Number', quotation.number],
      ['Date', quotation.valid_until ? new Date(quotation.created_at || Date.now()).toLocaleDateString('en-IN') : new Date().toLocaleDateString('en-IN')],
      ['Valid until', quotation.valid_until ? new Date(quotation.valid_until).toLocaleDateString('en-IN') : ''],
      ['Status', quotation.status]
    ]);
    y = drawParties(doc, y, customer, [['Place of supply', quotation.place_of_supply], ['Currency', totals.currency]]);
    y = drawItems(doc, y, lines, totals.currency);
    y = drawTotals(doc, y, totals, totals.currency);
    if (quotation.notes) {
      doc.font('Helvetica-Bold').fontSize(9).fillColor(INK).text('Notes', doc.page.margins.left, y + 20);
      doc.font('Helvetica').fontSize(9).fillColor(MUTED).text(quotation.notes, doc.page.margins.left, doc.y + 3, { width: 300 });
    }
    drawFooter(doc, branding, quotation.terms);
  });
}

export function invoicePdf({ branding, invoice, lines, totals, customer, payments }) {
  return renderPdf((doc) => {
    let y = drawHeader(doc, branding, 'TAX INVOICE', [
      ['Number', invoice.number],
      ['Issued', new Date(invoice.issue_date || Date.now()).toLocaleDateString('en-IN')],
      ['Due', invoice.due_date ? new Date(invoice.due_date).toLocaleDateString('en-IN') : ''],
      ['Status', invoice.status]
    ]);
    y = drawParties(doc, y, customer, [['Place of supply', invoice.place_of_supply], ['Currency', totals.currency]]);
    y = drawItems(doc, y, lines, totals.currency);
    y = drawTotals(doc, y, totals, totals.currency);

    const paid = (payments || []).reduce((a, p) => a + Number(p.amount), 0);
    const outstanding = Math.max(totals.total - paid, 0);
    doc.font('Helvetica-Bold').fontSize(9.5).fillColor(paid > 0 ? JADE : MUTED)
      .text(`Received ${money(paid, totals.currency)}   ·   Outstanding ${money(outstanding, totals.currency)}`,
        doc.page.margins.left, y + 6, { width: 300 });
    drawFooter(doc, branding, invoice.terms || invoice.notes);
  });
}

export function receiptPdf({ branding, payment, invoice, customer, totals }) {
  return renderPdf((doc) => {
    let y = drawHeader(doc, branding, 'PAYMENT RECEIPT', [
      ['Receipt', payment.reference || payment.id.slice(0, 8).toUpperCase()],
      ['Date', new Date(payment.received_at || Date.now()).toLocaleDateString('en-IN')],
      ['Invoice', invoice?.number || ''],
      ['Method', payment.method]
    ]);
    y = drawParties(doc, y, customer, [['Provider', payment.provider], ['Reference', payment.provider_ref]]);
    doc.font('Helvetica').fontSize(10).fillColor(INK)
      .text(`Received with thanks the sum of ${money(payment.amount, payment.currency)}`, doc.page.margins.left, y);
    doc.text(`Against invoice ${invoice?.number || '—'}${invoice ? ` of ${money(totals?.total || 0, payment.currency)}` : ''}`,
      doc.page.margins.left, doc.y + 4);
    drawFooter(doc, branding, null);
  });
}

/* ---------------------------------------------------------------- issuing -- */
export async function brandingFor(ctx) {
  const org = await one(`select name, settings, currency from organisations where id = $1`, [ctx.orgId]);
  const b = org?.settings?.branding || {};
  return {
    name: org?.name,
    legalName: b.legalName || org?.name,
    address1: b.address1, address2: b.address2, city: b.city, state: b.state,
    phone: b.phone, email: b.email, website: b.website, gstin: b.gstin,
    terms: b.terms, bank: b.bank, currency: org?.currency || 'INR'
  };
}

/** Snapshot an issued document so a reprint is reproducible. */
export async function issueDocument(ctx, docType, entityId) {
  const table = docType === 'invoice' ? 'invoices' : 'quotations';
  const record = await asUser(ctx, (t) => t.one(`select * from ${table} where id = $1`, [entityId]));
  if (!record) throw Object.assign(new Error('Document not found'), { status: 404 });

  const items = await asUser(ctx, (t) => t.q(
    `select * from ${docType === 'invoice' ? 'invoice_items' : 'quotation_items'}
      where ${docType === 'invoice' ? 'invoice_id' : 'quotation_id'} = $1 order by position, id`,
    [entityId]));
  const totals = computeTotals(items, {
    discount: record.discount_total || 0,
    taxMode: record.tax_mode || 'cgst_sgst',
    currency: record.currency || 'INR'
  });

  const number = record.number || await nextNumber(ctx, docType);
  await asUser(ctx, (t) => t.q(
    `update ${table} set number = $2, subtotal = $3, tax_total = $4, discount_total = $5,
            total = $6, updated_at = now() where id = $1`,
    [entityId, number, totals.subtotal, totals.tax_total, totals.discount_total, totals.total]));

  const version = await asUser(ctx, (t) => t.one(
    `select coalesce(max(version),0) + 1 as v from document_versions where doc_type = $1 and entity_id = $2`,
    [docType, entityId]));

  const snapshot = { record: { ...record, number }, items, totals };
  const row = await asUser(ctx, (t) => t.one(
    `insert into document_versions (org_id, doc_type, entity_id, number, version, snapshot, totals, issued_by)
     values ($1,$2,$3,$4,$5,$6,$7,$8) returning *`,
    [ctx.orgId, docType, entityId, number, version.v, JSON.stringify(snapshot), JSON.stringify(totals), ctx.userId]));

  await writeAudit(ctx, { action: `${docType}.issued`, entity: docType, entityId, after: { number, version: version.v } });
  return { number, version: version.v, totals, id: row.id };
}

/* ------------------------------------------------------------------ mount --- */
export function mountDocuments(app, { wrap, bad }) {
  app.get('/api/branding', requireAuth, wrap(async (req, res) => {
    const org = await one(`select settings from organisations where id = $1`, [req.ctx.orgId]);
    res.json(org?.settings?.branding || {});
  }));

  app.patch('/api/branding', requireAuth, requirePerm('settings.write'), wrap(async (req, res) => {
    const allowed = ['legalName', 'address1', 'address2', 'city', 'state', 'phone', 'email',
      'website', 'gstin', 'terms', 'bank', 'invoicePrefix', 'quotationPrefix', 'defaultTaxRate'];
    const branding = {};
    for (const k of allowed) if (req.body?.[k] !== undefined) branding[k] = req.body[k];
    await asUser(req.ctx, (t) => t.q(
      `update organisations set settings = jsonb_set(coalesce(settings,'{}'::jsonb),'{branding}', $1::jsonb), updated_at = now()
        where id = $2`,
      [JSON.stringify(branding), req.ctx.orgId]));
    await writeAudit(req.ctx, { action: 'branding.updated', entity: 'organisation', after: branding });
    res.json({ ok: true, branding });
  }));

  app.post('/api/documents/:type/:id/issue', requireAuth, requirePerm('quotation.write'), wrap(async (req, res) => {
    const type = req.params.type;
    if (!['quotation', 'invoice'].includes(type)) throw bad('Unknown document type', 404);
    res.json(await issueDocument(req.ctx, type, req.params.id));
  }));

  app.get('/api/documents/:type/:id/versions', requireAuth, requirePerm('quotation.read'), wrap(async (req, res) => {
    const rows = await asUser(req.ctx, (t) => t.q(
      `select id, number, version, totals, issued_at from document_versions
        where doc_type = $1 and entity_id = $2 order by version desc`,
      [req.params.type, req.params.id]));
    res.json({ data: rows });
  }));

  /** Always renders from the latest snapshot when one exists. */
  app.get('/api/documents/:type/:id.pdf', requireAuth, requirePerm('quotation.read'), wrap(async (req, res) => {
    const type = req.params.type;
    if (!['quotation', 'invoice'].includes(type)) throw bad('Unknown document type', 404);
    const branding = await brandingFor(req.ctx);

    const latest = await asUser(req.ctx, (t) => t.one(
      `select snapshot from document_versions where doc_type = $1 and entity_id = $2 order by version desc limit 1`,
      [type, req.params.id]));
    const snapshot = latest?.snapshot;

    let record, items, totals, contact, company;
    if (snapshot) {
      record = snapshot.record;
      items = snapshot.items;
      totals = snapshot.totals;
    } else {
      const table = type === 'invoice' ? 'invoices' : 'quotations';
      record = await asUser(req.ctx, (t) => t.one(`select * from ${table} where id = $1`, [req.params.id]));
      if (!record) throw bad('Document not found', 404);
      items = await asUser(req.ctx, (t) => t.q(
        `select * from ${type === 'invoice' ? 'invoice_items' : 'quotation_items'} where ${type === 'invoice' ? 'invoice_id' : 'quotation_id'} = $1`,
        [req.params.id]));
      totals = computeTotals(items, { discount: record.discount_total || 0, taxMode: record.tax_mode, currency: record.currency });
    }

    contact = record.contact_id
      ? await asUser(req.ctx, (t) => t.one(
        `select c.first_name, c.last_name, c.email, c.phone, co.name as company, co.city as address
           from contacts c left join companies co on co.id = c.company_id where c.id = $1`, [record.contact_id]))
      : null;
    company = record.company_id
      ? await asUser(req.ctx, (t) => t.one(`select name from companies where id = $1`, [record.company_id]))
      : null;

    const customer = {
      name: contact ? `${contact.first_name || ''} ${contact.last_name || ''}`.trim() : company?.name || 'Customer',
      company: company?.name, email: contact?.email, phone: contact?.phone,
      address: contact?.address, gstin: record.customer_gstin || null
    };

    const buf = type === 'invoice'
      ? await invoicePdf({ branding, invoice: record, lines: totals.lines, totals, customer, payments: [] })
      : await quotationPdf({ branding, quotation: record, lines: totals.lines, totals, customer });

    const name = `${type}-${record.number || req.params.id.slice(0, 8)}.pdf`;
    res.setHeader('content-type', 'application/pdf');
    res.setHeader('content-disposition', `inline; filename="${name}"`);
    res.send(buf);
  }));

  app.get('/api/documents/payment/:id.pdf', requireAuth, requirePerm('invoice.read'), wrap(async (req, res) => {
    const payment = await asUser(req.ctx, (t) => t.one(`select * from payments where id = $1`, [req.params.id]));
    if (!payment) throw bad('Payment not found', 404);
    const invoice = payment.invoice_id
      ? await asUser(req.ctx, (t) => t.one(`select * from invoices where id = $1`, [payment.invoice_id]))
      : null;
    const contact = invoice?.contact_id
      ? await asUser(req.ctx, (t) => t.one(`select first_name, last_name, email from contacts where id = $1`, [invoice.contact_id]))
      : null;
    const branding = await brandingFor(req.ctx);
    const buf = await receiptPdf({
      branding, payment, invoice,
      customer: { name: contact ? `${contact.first_name} ${contact.last_name}` : 'Customer', email: contact?.email },
      totals: invoice ? { total: invoice.total } : null
    });
    res.setHeader('content-type', 'application/pdf');
    res.setHeader('content-disposition', `inline; filename="receipt-${payment.id.slice(0, 8)}.pdf"`);
    res.send(buf);
  }));
}
