// Authentication, sessions and request context.
//
// Passwords: scrypt with a per-user salt.
// Sessions: opaque 32-byte token in an httpOnly cookie; only its SHA-256 hash
// is stored, so a database read cannot be replayed as a login.

import crypto from 'node:crypto';
import { q, one } from './db.js';

const SESSION_COOKIE = 'anvaya_session';
const ORG_COOKIE = 'anvaya_org';
const SESSION_DAYS = 7;

// ------------------------------------------------------------- passwords ---
export function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt$16384$8$1$${salt}$${hash}`;
}

export function verifyPassword(password, stored) {
  try {
    const [, , , , salt, hash] = stored.split('$');
    const candidate = crypto.scryptSync(password, salt, 64).toString('hex');
    return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(candidate, 'hex'));
  } catch {
    return false;
  }
}

export function validatePassword(pw) {
  if (typeof pw !== 'string' || pw.length < 10) return 'Password must be at least 10 characters';
  if (!/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) return 'Password must contain a letter and a number';
  return null;
}

// -------------------------------------------------------------- sessions ---
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');

export async function createSession(userId, req) {
  const token = crypto.randomBytes(32).toString('hex');
  const expires = new Date(Date.now() + SESSION_DAYS * 86400_000);
  const row = await one(
    `insert into sessions (user_id, token_hash, ip, user_agent, expires_at) values ($1,$2,$3,$4,$5) returning id`,
    [userId, sha(token), req.ip || null, (req.headers['user-agent'] || '').slice(0, 200), expires]
  );
  return { id: row.id, token, expires };
}

export async function destroySession(token) {
  if (!token) return;
  await q(`update sessions set revoked_at = now() where token_hash = $1`, [sha(token)]);
}

function readCookie(req, name) {
  const raw = req.headers.cookie || '';
  for (const part of raw.split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k === name) return decodeURIComponent(v.join('='));
  }
  return null;
}

export function setSessionCookie(res, token, expires) {
  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production',
    expires, path: '/'
  });
}

export function clearSessionCookie(res) {
  res.clearCookie(SESSION_COOKIE, { path: '/' });
  res.clearCookie(ORG_COOKIE, { path: '/' });
}

export function setOrgCookie(res, orgId) {
  res.cookie(ORG_COOKIE, orgId, {
    httpOnly: false, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', path: '/'
  });
}

// ------------------------------------------------------- request context ---
export async function loadContext(req, { allowPendingMfa = false } = {}) {
  const token = readCookie(req, SESSION_COOKIE);
  if (!token) return null;

  const session = await one(
    `select s.id, s.user_id, s.expires_at, s.revoked_at, s.mfa_ok,
            u.email, u.full_name, u.is_platform_admin, u.mfa_enabled_at
       from sessions s join users u on u.id = s.user_id
      where s.token_hash = $1`,
    [sha(token)]
  );
  if (!session || session.revoked_at || new Date(session.expires_at) < new Date()) return null;

  // A session that has not cleared the second factor is not usable, except by
  // the handful of endpoints that exist to clear it.
  if (session.mfa_ok === false && !allowPendingMfa) return null;

  const memberships = await q(
    `select m.id as member_id, m.org_id, m.status, m.title, r.id as role_id, r.key as role_key,
            r.name as role_name, r.permissions, o.name as org_name, o.currency, o.timezone, o.plan, o.settings
       from members m
       join roles r on r.id = m.role_id
       join organisations o on o.id = m.org_id
      where m.user_id = $1 and m.status = 'active' and o.deleted_at is null
      order by o.name`,
    [session.user_id]
  );
  if (!memberships.length) return null;

  const wanted = readCookie(req, ORG_COOKIE);
  const active = memberships.find(m => m.org_id === wanted) || memberships[0];

  const requireMfa = active.settings?.require_mfa === true || active.settings?.require_mfa === 'true';

  return {
    token,
    sessionId: session.id,
    mfaOk: session.mfa_ok !== false,
    mfaEnabled: Boolean(session.mfa_enabled_at),
    mfaSetupRequired: requireMfa && !session.mfa_enabled_at,
    userId: session.user_id,
    email: session.email,
    fullName: session.full_name,
    isPlatformAdmin: session.is_platform_admin,
    orgId: active.org_id,
    orgName: active.org_name,
    currency: active.currency,
    timezone: active.timezone,
    plan: active.plan,
    memberId: active.member_id,
    roleKey: active.role_key,
    roleName: active.role_name,
    perms: active.permissions,
    memberships: memberships.map(m => ({
      orgId: m.org_id, orgName: m.org_name, roleKey: m.role_key, roleName: m.role_name, plan: m.plan
    }))
  };
}

export async function requireAuth(req, res, next) {
  try {
    // An API key has already resolved a context; do not override it with a cookie.
    if (req.ctx) return next();
    const ctx = await loadContext(req);
    if (!ctx) return res.status(401).json({ error: 'Not authenticated' });
    req.ctx = ctx;
    next();
  } catch (err) {
    next(err);
  }
}

/** Route guard: requires a permission key in the active organisation. */
export function requirePerm(perm) {
  return (req, res, next) => {
    const perms = req.ctx?.perms || [];
    if (perms.includes('*') || perms.includes(perm)) return next();
    return res.status(403).json({ error: `Missing permission: ${perm}` });
  };
}

/** Platform-level guard for the super admin console. */
export function requirePlatformAdmin(req, res, next) {
  if (!req.ctx?.isPlatformAdmin) return res.status(403).json({ error: 'Platform admin only' });
  next();
}

export const cookies = { SESSION_COOKIE, ORG_COOKIE, readCookie };
