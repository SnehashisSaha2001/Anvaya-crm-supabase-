// ============================================================================
// Multi-factor authentication (P0 #1).
//
// TOTP per RFC 6238, implemented on node:crypto — no dependency, no service.
// Backup codes are single-use and stored as SHA-256 hashes.
// Organisation-level enforcement lives in organisations.settings.require_mfa.
// ============================================================================

import crypto from 'node:crypto';
import { q, one, asUser } from './db.js';
import { writeAudit } from './audit.js';
import { loadContext, hashPassword, verifyPassword } from './auth.js';
import { encrypt, decrypt } from './growth.js';

const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

function base32Encode(buf) {
  let bits = 0, value = 0, out = '';
  for (const byte of buf) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      out += B32[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}

function base32Decode(str) {
  let bits = 0, value = 0;
  const out = [];
  for (const ch of str.replace(/=+$/, '').toUpperCase()) {
    const idx = B32.indexOf(ch);
    if (idx === -1) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}

export function generateSecret() {
  return base32Encode(crypto.randomBytes(20));
}

export function totp(secret, at = Date.now(), step = 30, digits = 6) {
  const counter = Math.floor(at / 1000 / step);
  const buf = Buffer.alloc(8);
  buf.writeUInt32BE(Math.floor(counter / 2 ** 32), 0);
  buf.writeUInt32BE(counter >>> 0, 4);
  const hmac = crypto.createHmac('sha1', base32Decode(secret)).update(buf).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code = ((hmac[offset] & 0x7f) << 24)
    | ((hmac[offset + 1] & 0xff) << 16)
    | ((hmac[offset + 2] & 0xff) << 8)
    | (hmac[offset + 3] & 0xff);
  return String(code % 10 ** digits).padStart(digits, '0');
}

/** Accept the current step and one either side, for clock drift. */
export function verifyTotp(secret, code, at = Date.now()) {
  if (!secret || !/^\d{6}$/.test(String(code || '').trim())) return false;
  const clean = String(code).trim();
  for (const drift of [-1, 0, 1]) {
    if (totp(secret, at + drift * 30_000) === clean) return true;
  }
  return false;
}

const hashCode = (c) => crypto.createHash('sha256').update(c.replace(/[^A-Z0-9]/gi, '').toUpperCase()).digest('hex');

function makeBackupCodes(count = 10) {
  const codes = [];
  for (let i = 0; i < count; i += 1) {
    const raw = crypto.randomBytes(5).toString('hex').toUpperCase();
    codes.push(`${raw.slice(0, 5)}-${raw.slice(5, 10)}`);
  }
  return codes;
}

export function otpauthUrl(secret, email, issuer = 'Anvaya CRM') {
  const label = encodeURIComponent(`${issuer}:${email}`);
  return `otpauth://totp/${label}?secret=${secret}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=6&period=30`;
}

/** A session that has not passed the second factor is not a session yet. */
async function pendingUser(req) {
  const ctx = await loadContext(req, { allowPendingMfa: true });
  if (!ctx) throw Object.assign(new Error('Sign in first'), { status: 401 });
  return ctx;
}

export function mountMfa(app, { wrap, bad }) {
  app.get('/api/auth/mfa/status', wrap(async (req, res) => {
    const ctx = await loadContext(req, { allowPendingMfa: true });
    if (!ctx) return res.status(401).json({ error: 'Not signed in' });
    const user = await one(
      `select mfa_enabled_at, array_length(mfa_backup_codes,1) as backup_codes from users where id = $1`,
      [ctx.userId]);
    const org = await one(`select settings from organisations where id = $1`, [ctx.orgId]);
    res.json({
      enabled: Boolean(user.mfa_enabled_at),
      backupCodesLeft: user.backup_codes || 0,
      enforcedByOrg: org?.settings?.require_mfa === true || org?.settings?.require_mfa === 'true',
      sessionVerified: ctx.mfaOk !== false
    });
  }));

  /** Step 1: generate a secret. Nothing is enabled until a code is proven. */
  app.post('/api/auth/mfa/setup', wrap(async (req, res) => {
    const ctx = await pendingUser(req);
    if (!process.env.ENCRYPTION_KEY) throw bad('ENCRYPTION_KEY is not set on the server, so the secret cannot be stored safely', 500);
    const secret = generateSecret();
    await q(`update users set mfa_secret = $2, mfa_enabled_at = null where id = $1`, [ctx.userId, encrypt(secret)]);
    res.json({
      secret,
      otpauthUrl: otpauthUrl(secret, ctx.email),
      note: 'Scan this in your authenticator, then confirm with a 6-digit code. It is not active until you do.'
    });
  }));

  /** Step 2: prove possession, then enable and issue backup codes. */
  app.post('/api/auth/mfa/enable', wrap(async (req, res) => {
    const ctx = await pendingUser(req);
    const user = await one(`select mfa_secret from users where id = $1`, [ctx.userId]);
    const secret = decrypt(user.mfa_secret);
    if (!secret) throw bad('Start the setup again — the stored secret could not be read', 409);
    if (!verifyTotp(secret, req.body?.code)) throw bad('That code is not valid. Check the clock on your phone and try again.');

    const codes = makeBackupCodes();
    await q(
      `update users set mfa_enabled_at = now(), mfa_last_used_at = now(), mfa_backup_codes = $2 where id = $1`,
      [ctx.userId, codes.map(hashCode)]);
    await q(`update sessions set mfa_ok = true where id = $1`, [ctx.sessionId]);
    await writeAudit(ctx, { action: 'mfa.enabled', entity: 'user', entityId: ctx.userId });
    res.json({ ok: true, backupCodes: codes, note: 'Store these somewhere safe. Each one works once.' });
  }));

  /** Second factor at sign-in. */
  app.post('/api/auth/mfa/verify', wrap(async (req, res) => {
    const ctx = await pendingUser(req);
    const { code } = req.body || {};
    const user = await one(
      `select mfa_secret, mfa_enabled_at, mfa_backup_codes from users where id = $1`, [ctx.userId]);
    if (!user.mfa_enabled_at) throw bad('MFA is not enabled for this account', 409);

    let ok = verifyTotp(decrypt(user.mfa_secret), code);
    let usedBackup = false;

    if (!ok) {
      const hash = hashCode(String(code || ''));
      if ((user.mfa_backup_codes || []).includes(hash)) {
        ok = true;
        usedBackup = true;
        const remaining = user.mfa_backup_codes.filter((c) => c !== hash);
        await q(`update users set mfa_backup_codes = $2 where id = $1`, [ctx.userId, remaining]);
      }
    }
    if (!ok) throw bad('That code is not valid', 401);

    await q(`update sessions set mfa_ok = true where id = $1`, [ctx.sessionId]);
    await q(`update users set mfa_last_used_at = now() where id = $1`, [ctx.userId]);
    await writeAudit(ctx, { action: usedBackup ? 'mfa.backup_code_used' : 'mfa.verified', entity: 'user', entityId: ctx.userId });
    res.json({ ok: true, usedBackupCode: usedBackup });
  }));

  app.post('/api/auth/mfa/disable', wrap(async (req, res) => {
    const ctx = await pendingUser(req);
    const { password } = req.body || {};
    const user = await one(`select password_hash from users where id = $1`, [ctx.userId]);
    if (!verifyPassword(password || '', user.password_hash)) {
      throw bad('Enter your password to turn off two-factor authentication', 401);
    }
    await q(
      `update users set mfa_secret = null, mfa_enabled_at = null, mfa_backup_codes = '{}' where id = $1`,
      [ctx.userId]);
    await writeAudit(ctx, { action: 'mfa.disabled', entity: 'user', entityId: ctx.userId });
    res.json({ ok: true });
  }));

  app.post('/api/auth/mfa/backup-codes', wrap(async (req, res) => {
    const ctx = await pendingUser(req);
    const user = await one(`select mfa_enabled_at, password_hash from users where id = $1`, [ctx.userId]);
    if (!user.mfa_enabled_at) throw bad('MFA is not enabled', 409);
    if (!verifyPassword(req.body?.password || '', user.password_hash)) throw bad('Password is required', 401);
    const codes = makeBackupCodes();
    await q(`update users set mfa_backup_codes = $2 where id = $1`, [ctx.userId, codes.map(hashCode)]);
    await writeAudit(ctx, { action: 'mfa.backup_codes_regenerated', entity: 'user', entityId: ctx.userId });
    res.json({ backupCodes: codes });
  }));
}

export { hashPassword };
