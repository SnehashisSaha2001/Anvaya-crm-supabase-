-- ============================================================================
-- Anvaya CRM — 001 schema
-- Plain PostgreSQL (13+). Applies unchanged to Supabase.
-- Every organisation-owned table carries org_id and is protected by RLS
-- in 002_rls.sql.
-- ============================================================================

create schema if not exists app;

-- Application role. Requests run as this role so RLS is enforced.
do $$
begin
  if not exists (select 1 from pg_roles where rolname = 'app_user') then
    create role app_user nologin;
  end if;
end $$;

-- ---------------------------------------------------------------- helpers ---
create or replace function app.current_org() returns uuid
  language sql stable as $$
    select nullif(current_setting('app.org_id', true), '')::uuid
$$;

create or replace function app.current_user() returns uuid
  language sql stable as $$
    select nullif(current_setting('app.user_id', true), '')::uuid
$$;

create or replace function app.perms() returns text[]
  language sql stable as $$
    select coalesce(string_to_array(nullif(current_setting('app.perms', true), ''), ','), '{}'::text[])
$$;

create or replace function app.has_perm(p text) returns boolean
  language sql stable as $$
    select p = any(app.perms()) or '*' = any(app.perms())
$$;

create or replace function app.touch() returns trigger
  language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- ----------------------------------------------------------- organisations ---
create table if not exists organisations (
  id            uuid primary key default gen_random_uuid(),
  name          text not null,
  slug          text not null unique,
  industry      text,
  currency      char(3) not null default 'INR',
  timezone      text not null default 'Asia/Kolkata',
  locale        text not null default 'en-IN',
  fiscal_start_month int not null default 4 check (fiscal_start_month between 1 and 12),
  working_hours jsonb not null default '{"days":[1,2,3,4,5,6],"start":"09:30","end":"18:30"}',
  logo_url      text,
  plan          text not null default 'professional',
  status        text not null default 'active' check (status in ('active','suspended','deleted')),
  settings      jsonb not null default '{}',
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  deleted_at    timestamptz
);

create table if not exists workspaces (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  name       text not null,
  slug       text not null,
  is_default boolean not null default false,
  settings   jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (org_id, slug)
);

create table if not exists users (
  id                uuid primary key default gen_random_uuid(),
  email             text not null unique,
  password_hash     text not null,
  full_name         text not null,
  phone             text,
  avatar_initials   text,
  email_verified_at timestamptz,
  mfa_secret        text,
  is_platform_admin boolean not null default false,
  last_login_at     timestamptz,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create table if not exists roles (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  key         text not null,
  name        text not null,
  description text,
  permissions text[] not null default '{}',
  is_system   boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (org_id, key)
);

create table if not exists members (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  user_id     uuid not null references users(id) on delete cascade,
  role_id     uuid not null references roles(id),
  workspace_id uuid references workspaces(id) on delete set null,
  status      text not null default 'active' check (status in ('invited','active','suspended')),
  title       text,
  department  text,
  invited_by  uuid references users(id),
  invited_at  timestamptz,
  joined_at   timestamptz,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (org_id, user_id)
);

create table if not exists sessions (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references users(id) on delete cascade,
  token_hash text not null unique,
  ip         text,
  user_agent text,
  expires_at timestamptz not null,
  revoked_at timestamptz,
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------------- CRM ---
create table if not exists companies (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references organisations(id) on delete cascade,
  name           text not null,
  domain         text,
  industry       text,
  size_band      text,
  annual_revenue numeric(16,2),
  phone          text,
  website        text,
  city           text,
  country        text default 'India',
  address        jsonb not null default '{}',
  parent_id      uuid references companies(id) on delete set null,
  owner_id       uuid references members(id) on delete set null,
  health_score   int not null default 60 check (health_score between 0 and 100),
  tags           text[] not null default '{}',
  custom         jsonb not null default '{}',
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  deleted_at     timestamptz
);

create table if not exists contacts (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  company_id   uuid references companies(id) on delete set null,
  first_name   text not null,
  last_name    text,
  email        text,
  phone        text,
  title        text,
  city         text,
  owner_id     uuid references members(id) on delete set null,
  tags         text[] not null default '{}',
  consent      jsonb not null default '{"email":true,"whatsapp":false,"calls":true,"recorded_at":null}',
  health_score int not null default 60 check (health_score between 0 and 100),
  custom       jsonb not null default '{}',
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  deleted_at   timestamptz
);
create index if not exists contacts_org_company on contacts (org_id, company_id);
create index if not exists contacts_email on contacts (org_id, lower(email));

create table if not exists leads (
  id                  uuid primary key default gen_random_uuid(),
  org_id              uuid not null references organisations(id) on delete cascade,
  name                text not null,
  company_name        text,
  email               text,
  phone               text,
  source              text not null default 'website',
  status              text not null default 'new'
                      check (status in ('new','contacted','qualified','proposal','negotiation','converted','lost')),
  score               int check (score between 0 and 100),
  score_reason        text,
  owner_id            uuid references members(id) on delete set null,
  estimated_value     numeric(16,2) not null default 0,
  currency            char(3) not null default 'INR',
  notes               text,
  converted_contact_id uuid references contacts(id) on delete set null,
  converted_deal_id   uuid,
  lost_reason         text,
  last_contacted_at   timestamptz,
  custom              jsonb not null default '{}',
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  deleted_at          timestamptz
);
create index if not exists leads_org_status on leads (org_id, status);

create table if not exists pipelines (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  name       text not null,
  is_default boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists stages (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  pipeline_id uuid not null references pipelines(id) on delete cascade,
  name        text not null,
  position    int not null default 0,
  probability int not null default 10 check (probability between 0 and 100),
  is_won      boolean not null default false,
  is_lost     boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists deals (
  id                  uuid primary key default gen_random_uuid(),
  org_id              uuid not null references organisations(id) on delete cascade,
  pipeline_id         uuid not null references pipelines(id),
  stage_id            uuid not null references stages(id),
  company_id          uuid references companies(id) on delete set null,
  contact_id          uuid references contacts(id) on delete set null,
  title               text not null,
  value               numeric(16,2) not null default 0,
  currency            char(3) not null default 'INR',
  probability         int check (probability between 0 and 100),
  expected_close_date date,
  owner_id            uuid references members(id) on delete set null,
  status              text not null default 'open' check (status in ('open','won','lost')),
  lost_reason         text,
  competitor          text,
  source_lead_id      uuid references leads(id) on delete set null,
  stage_changed_at    timestamptz not null default now(),
  custom              jsonb not null default '{}',
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  deleted_at          timestamptz
);
create index if not exists deals_org_status on deals (org_id, status);
create index if not exists deals_org_stage on deals (org_id, stage_id);

create table if not exists activities (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  type        text not null check (type in ('call','email','meeting','note','visit')),
  subject     text not null,
  body        text,
  contact_id  uuid references contacts(id) on delete cascade,
  company_id  uuid references companies(id) on delete cascade,
  deal_id     uuid references deals(id) on delete cascade,
  ticket_id   uuid,
  owner_id    uuid references members(id) on delete set null,
  occurred_at timestamptz not null default now(),
  duration_min int,
  created_by  uuid references users(id),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists activities_org_contact on activities (org_id, contact_id, occurred_at desc);

create table if not exists tasks (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  title        text not null,
  notes        text,
  due_date     date,
  due_time     time,
  priority     text not null default 'medium' check (priority in ('low','medium','high','urgent')),
  status       text not null default 'open' check (status in ('open','in_progress','done','cancelled')),
  assignee_id  uuid references members(id) on delete set null,
  related_type text,
  related_id   uuid,
  recurrence   text,
  completed_at timestamptz,
  created_by   uuid references users(id),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists tasks_org_assignee on tasks (org_id, assignee_id, status);

-- ------------------------------------------------------------- service ------
create table if not exists tickets (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  number        text not null,
  subject       text not null,
  description   text,
  contact_id    uuid references contacts(id) on delete set null,
  company_id    uuid references companies(id) on delete set null,
  deal_id       uuid references deals(id) on delete set null,
  priority      text not null default 'medium' check (priority in ('low','medium','high','critical')),
  status        text not null default 'open' check (status in ('open','in_progress','waiting','resolved','closed')),
  category      text,
  assignee_id   uuid references members(id) on delete set null,
  sla_policy    text not null default 'standard',
  sla_due_at    timestamptz,
  first_response_at timestamptz,
  resolved_at   timestamptz,
  csat          int check (csat between 1 and 5),
  created_by    uuid references users(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (org_id, number)
);
create index if not exists tickets_org_status on tickets (org_id, status);

create table if not exists ticket_comments (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  ticket_id  uuid not null references tickets(id) on delete cascade,
  author_id  uuid references users(id),
  body       text not null,
  is_internal boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists knowledge_articles (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  title      text not null,
  body       text not null,
  category   text,
  is_public  boolean not null default false,
  created_by uuid references users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ------------------------------------------------------------ marketing ----
create table if not exists campaigns (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references organisations(id) on delete cascade,
  name           text not null,
  channel        text not null default 'email' check (channel in ('email','sms','whatsapp')),
  status         text not null default 'draft' check (status in ('draft','scheduled','sending','sent','paused','failed')),
  subject        text,
  body           text,
  audience       jsonb not null default '{}',
  scheduled_at   timestamptz,
  sent_at        timestamptz,
  provider       text,
  provider_ref   text,
  stats          jsonb not null default '{"sent":0,"delivered":0,"opened":0,"clicked":0,"bounced":0}',
  created_by     uuid references users(id),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

create table if not exists campaign_recipients (
  id                  uuid primary key default gen_random_uuid(),
  org_id              uuid not null references organisations(id) on delete cascade,
  campaign_id         uuid not null references campaigns(id) on delete cascade,
  contact_id          uuid references contacts(id) on delete cascade,
  status              text not null default 'queued' check (status in ('queued','sent','delivered','opened','clicked','bounced','failed')),
  provider_message_id text,
  error               text,
  updated_at          timestamptz not null default now(),
  created_at          timestamptz not null default now()
);

-- ------------------------------------------------------------- commerce ----
create table if not exists products (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  sku           text not null,
  name          text not null,
  category      text,
  description   text,
  unit_price    numeric(14,2) not null default 0,
  tax_rate      numeric(5,2) not null default 18,
  stock_qty     numeric(14,2) not null default 0,
  reorder_point numeric(14,2) not null default 0,
  uom           text default 'unit',
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (org_id, sku)
);

create table if not exists quotations (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  number        text not null,
  deal_id       uuid references deals(id) on delete set null,
  contact_id    uuid references contacts(id) on delete set null,
  company_id    uuid references companies(id) on delete set null,
  status        text not null default 'draft' check (status in ('draft','sent','accepted','rejected','expired')),
  issue_date    date not null default current_date,
  valid_until   date,
  currency      char(3) not null default 'INR',
  subtotal      numeric(16,2) not null default 0,
  discount_total numeric(16,2) not null default 0,
  tax_total     numeric(16,2) not null default 0,
  total         numeric(16,2) not null default 0,
  notes         text,
  terms         text,
  version       int not null default 1,
  approved_at   timestamptz,
  created_by    uuid references users(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (org_id, number)
);

create table if not exists quotation_items (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  quotation_id uuid not null references quotations(id) on delete cascade,
  product_id  uuid references products(id) on delete set null,
  description text not null,
  qty         numeric(14,2) not null default 1,
  unit_price  numeric(14,2) not null default 0,
  discount    numeric(14,2) not null default 0,
  tax_rate    numeric(5,2) not null default 18,
  line_total  numeric(16,2) not null default 0,
  position    int not null default 0
);

create table if not exists invoices (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  number        text not null,
  quotation_id  uuid references quotations(id) on delete set null,
  deal_id       uuid references deals(id) on delete set null,
  contact_id    uuid references contacts(id) on delete set null,
  company_id    uuid references companies(id) on delete set null,
  status        text not null default 'draft' check (status in ('draft','sent','partially_paid','paid','overdue','cancelled')),
  issue_date    date not null default current_date,
  due_date      date,
  currency      char(3) not null default 'INR',
  subtotal      numeric(16,2) not null default 0,
  tax_total     numeric(16,2) not null default 0,
  total         numeric(16,2) not null default 0,
  amount_paid   numeric(16,2) not null default 0,
  notes         text,
  paid_at       timestamptz,
  created_by    uuid references users(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (org_id, number)
);

create table if not exists invoice_items (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  invoice_id  uuid not null references invoices(id) on delete cascade,
  description text not null,
  qty         numeric(14,2) not null default 1,
  unit_price  numeric(14,2) not null default 0,
  tax_rate    numeric(5,2) not null default 18,
  line_total  numeric(16,2) not null default 0,
  position    int not null default 0
);

create table if not exists payments (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  invoice_id   uuid not null references invoices(id) on delete cascade,
  amount       numeric(16,2) not null,
  method       text not null default 'bank_transfer',
  provider     text,
  provider_ref text,
  status       text not null default 'succeeded' check (status in ('pending','succeeded','failed','refunded')),
  received_at  timestamptz not null default now(),
  created_at   timestamptz not null default now()
);

-- ------------------------------------------------------------- delivery ----
create table if not exists projects (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  name        text not null,
  deal_id     uuid references deals(id) on delete set null,
  company_id  uuid references companies(id) on delete set null,
  status      text not null default 'planned' check (status in ('planned','active','on_hold','completed','cancelled')),
  start_date  date,
  end_date    date,
  budget      numeric(16,2) not null default 0,
  spent       numeric(16,2) not null default 0,
  progress    int not null default 0 check (progress between 0 and 100),
  manager_id  uuid references members(id) on delete set null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists milestones (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  project_id  uuid not null references projects(id) on delete cascade,
  name        text not null,
  due_date    date,
  completed_at timestamptz,
  position    int not null default 0
);

-- ----------------------------------------------------------- automation ----
create table if not exists workflows (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  name        text not null,
  description text,
  status      text not null default 'draft' check (status in ('draft','active','paused')),
  version     int not null default 1,
  trigger     jsonb not null,
  conditions  jsonb not null default '[]',
  actions     jsonb not null default '[]',
  run_count   int not null default 0,
  last_run_at timestamptz,
  created_by  uuid references users(id),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists workflow_runs (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references organisations(id) on delete cascade,
  workflow_id    uuid not null references workflows(id) on delete cascade,
  workflow_version int not null default 1,
  trigger_entity text,
  trigger_id     uuid,
  status         text not null default 'running' check (status in ('running','succeeded','failed','skipped','awaiting_approval')),
  context        jsonb not null default '{}',
  error          text,
  started_at     timestamptz not null default now(),
  finished_at    timestamptz
);

create table if not exists workflow_steps (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  run_id     uuid not null references workflow_runs(id) on delete cascade,
  step_index int not null default 0,
  node_type  text not null,
  status     text not null default 'succeeded',
  output     jsonb not null default '{}',
  error      text,
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------------- AI ----
create table if not exists ai_runs (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  user_id     uuid references users(id),
  agent       text not null default 'copilot',
  provider    text,
  model       text,
  prompt      text,
  response    text,
  status      text not null default 'succeeded' check (status in ('running','succeeded','failed')),
  tokens_in   int not null default 0,
  tokens_out  int not null default 0,
  latency_ms  int,
  error       text,
  created_at  timestamptz not null default now()
);

create table if not exists ai_actions (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  run_id       uuid references ai_runs(id) on delete cascade,
  action       text not null,
  target_table text,
  target_id    uuid,
  payload      jsonb not null default '{}',
  status       text not null default 'proposed' check (status in ('proposed','approved','rejected','applied','failed')),
  approved_by  uuid references users(id),
  applied_at   timestamptz,
  created_at   timestamptz not null default now()
);

-- ------------------------------------------------------------- platform ----
create table if not exists custom_fields (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  entity     text not null check (entity in ('lead','contact','company','deal','ticket','project')),
  key        text not null,
  label      text not null,
  type       text not null default 'text' check (type in ('text','number','date','select','multiselect','boolean','url')),
  options    jsonb not null default '[]',
  required   boolean not null default false,
  position   int not null default 0,
  created_at timestamptz not null default now(),
  unique (org_id, entity, key)
);

create table if not exists custom_values (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  field_id   uuid not null references custom_fields(id) on delete cascade,
  record_id  uuid not null,
  value      text,
  updated_at timestamptz not null default now(),
  unique (field_id, record_id)
);

create table if not exists notifications (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  user_id    uuid not null references users(id) on delete cascade,
  type       text not null default 'info',
  title      text not null,
  body       text,
  link       text,
  read_at    timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists audit_logs (
  id         uuid primary key default gen_random_uuid(),
  org_id     uuid not null references organisations(id) on delete cascade,
  actor_id   uuid references users(id),
  actor_name text,
  action     text not null,
  entity     text,
  entity_id  uuid,
  before     jsonb,
  after      jsonb,
  ip         text,
  created_at timestamptz not null default now()
);
create index if not exists audit_org_created on audit_logs (org_id, created_at desc);

create table if not exists subscriptions (
  id                 uuid primary key default gen_random_uuid(),
  org_id             uuid not null references organisations(id) on delete cascade,
  plan               text not null default 'professional',
  status             text not null default 'trialing' check (status in ('trialing','active','past_due','cancelled')),
  seats              int not null default 5,
  trial_ends_at      timestamptz,
  current_period_end timestamptz,
  usage              jsonb not null default '{"ai_credits":0,"emails":0}',
  limits             jsonb not null default '{"seats":5,"ai_credits":2000,"emails":5000}',
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

create table if not exists integrations (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  provider     text not null,
  status       text not null default 'disconnected' check (status in ('disconnected','pending','connected','error')),
  scopes       text[] not null default '{}',
  config       jsonb not null default '{}',
  connected_at timestamptz,
  last_error   text,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  unique (org_id, provider)
);

-- forward reference: leads -> deals (deals is created after leads)
alter table leads drop constraint if exists leads_converted_deal_fk;
alter table leads add constraint leads_converted_deal_fk
  foreign key (converted_deal_id) references deals(id) on delete set null;

-- updated_at triggers
do $$
declare t text;
begin
  foreach t in array array[
    'organisations','workspaces','users','roles','members','companies','contacts','leads',
    'pipelines','stages','deals','activities','tasks','tickets','knowledge_articles',
    'campaigns','products','quotations','invoices','projects','workflows','custom_fields',
    'subscriptions','integrations'
  ]
  loop
    execute format('drop trigger if exists touch_%1$s on %1$I', t);
    execute format('create trigger touch_%1$s before update on %1$I for each row execute function app.touch()', t);
  end loop;
end $$;
