// Seeds a demo workspace. Run with: npm run seed
// Safe to re-run: it wipes and rebuilds the demo organisation only.

import { initDb, migrate, q, one, tx } from '../src/db.js';
import { hashPassword } from '../src/auth.js';
import { rolePayload, ROLE_TEMPLATES } from '../src/permissions.js';

const PASSWORD = process.env.SEED_PASSWORD || 'AnvayaDemo2026';

const USERS = [
  { email: 'sneha@brightline.in', name: 'Snehasis Saha', role: 'owner', title: 'Managing Director' },
  { email: 'rohit@brightline.in', name: 'Rohit Kapoor', role: 'manager', title: 'Sales Manager' },
  { email: 'aarti@brightline.in', name: 'Aarti Sharma', role: 'sales', title: 'Account Executive' },
  { email: 'prakash@brightline.in', name: 'Prakash Kamath', role: 'support', title: 'Service Lead' },
  { email: 'sana@brightline.in', name: 'Sana Pillai', role: 'finance', title: 'Finance' }
];

const COMPANIES = [
  ['Meridian Retail Group', 'meridianretail.in', 'Retail', '500-1000', 48000000, 'Bengaluru', 78],
  ['Sunrise Hospitals', 'sunrisehospitals.in', 'Healthcare', '1000+', 96000000, 'Hyderabad', 64],
  ['Deccan Precision Works', 'deccanprecision.in', 'Manufacturing', '250-500', 32000000, 'Pune', 71],
  ['Fresco Foods', 'frescofoods.in', 'Cold chain', '100-250', 14000000, 'Nashik', 52],
  ['Palm Grove Resorts', 'palmgroveresorts.com', 'Hospitality', '50-100', 8000000, 'Coorg', 88],
  ['Skyline Cargo', 'skylinecargo.co.in', 'Logistics', '500-1000', 55000000, 'Mumbai', 59]
];

const CONTACTS = [
  ['Rahul', 'Menon', 'Head of Projects', 0, 'rahul.menon@meridianretail.in', '+91 98450 21188', 'Bengaluru', 78],
  ['Kavita', 'Rao', 'Chief Information Officer', 1, 'kavita.rao@sunrisehospitals.in', '+91 90080 33214', 'Hyderabad', 64],
  ['Arjun', 'Deshmukh', 'Plant Head', 2, 'a.deshmukh@deccanprecision.in', '+91 98220 67315', 'Pune', 71],
  ['Neha', 'Kulkarni', 'Operations Manager', 3, 'neha.k@frescofoods.in', '+91 97650 40931', 'Nashik', 52],
  ['Anita', 'Bose', 'General Manager', 4, 'anita.bose@palmgroveresorts.com', '+91 98860 22317', 'Coorg', 88],
  ['Imran', 'Shaikh', 'Logistics Director', 5, 'imran.shaikh@skylinecargo.co.in', '+91 98333 90127', 'Mumbai', 59],
  ['Priya', 'Nair', 'Facilities Head', 0, 'priya@meridianretail.in', '+91 99001 44720', 'Bengaluru', 66],
  ['Meera', 'Iyer', 'Administrative Officer', 1, 'meera.iyer@sunrisehospitals.in', '+91 94480 51206', 'Chennai', 61]
];

const LEADS = [
  ['Rahul Menon', 'Meridian Retail Group', 'website', 'qualified', 86, 4280000, 0, 'rahul.menon@meridianretail.in'],
  ['Priya Nair', 'Meridian Retail Group', 'referral', 'new', 72, 1860000, 0, 'priya@meridianretail.in'],
  ['Arjun Deshmukh', 'Deccan Precision Works', 'exhibition', 'proposal', 91, 5240000, 1, 'a.deshmukh@deccanprecision.in'],
  ['Kavita Rao', 'Sunrise Hospitals', 'cold_call', 'qualified', 64, 940000, 1, 'kavita.rao@sunrisehospitals.in'],
  ['Imran Shaikh', 'Skyline Cargo', 'linkedin', 'contacted', 78, 8900000, 0, 'imran.shaikh@skylinecargo.co.in'],
  ['Meera Iyer', 'Sunrise Hospitals', 'website', 'contacted', 58, 2760000, 2, 'meera.iyer@sunrisehospitals.in'],
  ['Neha Kulkarni', 'Fresco Foods', 'outbound', 'qualified', 81, 1150000, 1, 'neha.k@frescofoods.in'],
  ['Sanjay Patil', 'Palm Grove Resorts', 'referral', 'new', 45, 620000, 2, 'sanjay.patil@palmgroveresorts.com']
];

// [title, companyIdx, contactIdx, stagePosition, value, probability, ownerIdx, closeInDays]
const DEALS = [
  ['350-camera rollout — Phase 2', 0, 0, 3, 4280000, 75, 0, 26],
  ['Warehouse perimeter upgrade', 5, 5, 2, 1860000, 55, 1, 33],
  ['AMC renewal — 3 sites', 1, 1, 3, 940000, 80, 0, 13],
  ['Plant CCTV + fire alarm', 2, 2, 2, 5240000, 60, 1, 40],
  ['Cold storage monitoring', 3, 3, 3, 1150000, 70, 1, 28],
  ['Cargo terminal — pilot', 5, 5, 2, 8900000, 50, 0, 56],
  ['Lobby & parking coverage', 4, 4, 4, 780000, 100, 2, -15],
  ['School bus GPS package', 1, 1, 4, 340000, 100, 2, -24],
  ['Showroom chain refresh', 0, 6, 5, 560000, 0, 2, -35],
  ['Retail chain — 14 outlets', 0, 6, 0, 3120000, 20, 1, 74],
  ['Resort staff quarters — Phase 2', 4, 4, 4, 920000, 100, 2, -78],
  ['Bank branch surveillance', 1, 1, 4, 1480000, 100, 0, -112],
  ['Cold store retrofit — 2 sites', 3, 3, 4, 640000, 100, 1, -46]
];

const TICKETS = [
  ['TKT-1084', 'NVR offline at Whitefield store', 0, 0, 'critical', 'open', 1, 'Installation'],
  ['TKT-1081', 'Camera 12 flickering at night', 1, 1, 'high', 'in_progress', 2, 'Hardware'],
  ['TKT-1079', 'Add 4 users to mobile app', 3, 3, 'medium', 'in_progress', 1, 'Access'],
  ['TKT-1076', 'AMC invoice mismatch — Q3', 4, 4, 'medium', 'open', 2, 'Billing'],
  ['TKT-1072', 'Access card not working — gate 2', 2, 2, 'high', 'open', 1, 'Access'],
  ['TKT-1061', 'DVR replacement under warranty', 5, 5, 'high', 'resolved', 1, 'Hardware']
];

const PRODUCTS = [
  ['CAM-IP-4MP', '4MP IP dome camera', 'Cameras', 6400, 18, 120, 30],
  ['CAM-PTZ-2MP', '2MP PTZ camera, 25x zoom', 'Cameras', 24500, 18, 18, 6],
  ['NVR-32CH', '32-channel NVR with 8TB storage', 'Recorders', 68000, 18, 12, 4],
  ['AMC-STD', 'Annual maintenance — standard site', 'Services', 96000, 18, 999, 0]
];

await initDb();
await migrate();

const existing = await one(`select id from organisations where slug = 'brightline-security'`);
const demoEmails = USERS.map(u => u.email);

if (existing) {
  await q(`delete from organisations where id = $1`, [existing.id]);
  console.log('Removed previous demo organisation');
}
// Re-runs must not collide with the unique email constraint.
await q(`delete from users where lower(email) = any($1::text[])`, [demoEmails]);

const password = hashPassword(PASSWORD);

const org = await one(
  `insert into organisations (name, slug, industry, currency, timezone, plan)
   values ('Brightline Security Solutions','brightline-security','Security systems integrator','INR','Asia/Kolkata','professional')
   returning *`
);

for (const key of Object.keys(ROLE_TEMPLATES)) {
  const p = rolePayload(key);
  await q(
    `insert into roles (org_id, key, name, description, permissions, is_system) values ($1,$2,$3,$4,$5,true)`,
    [org.id, p.key, p.name, p.description, p.permissions]
  );
}

const ws = await one(
  `insert into workspaces (org_id, name, slug, is_default) values ($1,'Brightline Security','default',true) returning id`,
  [org.id]
);

const memberIds = [];
for (const u of USERS) {
  const user = await one(
    `insert into users (email, password_hash, full_name, email_verified_at) values ($1,$2,$3, now()) returning id`,
    [u.email, password, u.name]
  );
  const role = await one(`select id from roles where org_id = $1 and key = $2`, [org.id, u.role]);
  const member = await one(
    `insert into members (org_id, user_id, role_id, workspace_id, status, title, joined_at)
     values ($1,$2,$3,$4,'active',$5, now() - interval '8 months') returning id`,
    [org.id, user.id, role.id, ws.id, u.title]
  );
  memberIds.push(member.id);
}

const pipeline = await one(
  `insert into pipelines (org_id, name, is_default) values ($1,'Enterprise security',true) returning id`, [org.id]
);
const stages = [];
for (const [i, [name, prob]] of [
  ['Discovery', 10], ['Site survey', 25], ['Proposal sent', 45],
  ['Negotiation', 70], ['Closed won', 100], ['Closed lost', 0]
].entries()) {
  stages.push(await one(
    `insert into stages (org_id, pipeline_id, name, position, probability, is_won, is_lost)
     values ($1,$2,$3,$4,$5,$6,$7) returning *`,
    [org.id, pipeline.id, name, i, prob, name === 'Closed won', name === 'Closed lost']
  ));
}
await q(
  `insert into pipelines (org_id, name, is_default) values ($1,'AMC renewals',false)`,
  [org.id]
);

const companyIds = [];
for (const [name, domain, industry, size, revenue, city, health] of COMPANIES) {
  const c = await one(
    `insert into companies (org_id, name, domain, industry, size_band, annual_revenue, city, owner_id, health_score, tags)
     values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) returning id`,
    [org.id, name, domain, industry, size, revenue, city, memberIds[0], health,
      industry === 'Retail' ? ['key-account', 'multi-site'] : []]
  );
  companyIds.push(c.id);
}

const contactIds = [];
const CONTACT_AGE_DAYS = [1, 5, 9, 14, 21, 30, 45, 60];
for (const [i, [first, last, title, ci, email, phone, city, health]] of CONTACTS.entries()) {
  const c = await one(
    `insert into contacts (org_id, company_id, first_name, last_name, title, email, phone, city, owner_id,
                           health_score, tags, consent, created_at)
     values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12, now() - ($13 || ' days')::interval) returning id`,
    [org.id, companyIds[ci], first, last, title, email, phone, city, memberIds[ci % memberIds.length], health,
      ['decision-maker'], JSON.stringify({ email: true, whatsapp: ci === 0, calls: true, recorded_at: '2026-08-12' }),
      String(CONTACT_AGE_DAYS[i] ?? 30)]
  );
  contactIds.push(c.id);
}

for (const [name, company, source, status, score, value, ownerIdx, email] of LEADS) {
  await q(
    `insert into leads (org_id, name, company_name, email, source, status, score, score_reason, estimated_value, owner_id, created_at, last_contacted_at)
     values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10, now() - ($11 || ' days')::interval, now() - ($11 || ' days')::interval)`,
    [org.id, name, company, email, source, status, score,
      score >= 80 ? 'High engagement, budget confirmed, decision-maker met'
        : score >= 60 ? 'Reasonable fit, budget unclear' : 'Low engagement so far',
      value, memberIds[ownerIdx], String(5 + (score % 20))]
  );
}

const dealIds = [];
for (const [title, ci, cti, stagePos, value, prob, ownerIdx, closeInDays] of DEALS) {
  const stage = stages[stagePos];
  const status = stage.is_won ? 'won' : stage.is_lost ? 'lost' : 'open';
  const d = await one(
    `insert into deals (org_id, pipeline_id, stage_id, company_id, contact_id, title, value, probability,
                        expected_close_date, owner_id, status, stage_changed_at, lost_reason, created_at)
     values ($1,$2,$3,$4,$5,$6,$7,$8, current_date + $9::int, $10, $11, now() - ($12 || ' days')::interval, $13,
             now() - ($12 || ' days')::interval - interval '20 days')
     returning id`,
    [org.id, pipeline.id, stage.id, companyIds[ci], contactIds[cti], title, value, prob, closeInDays,
      memberIds[ownerIdx], status, String(status === 'open' ? 4 + (value % 12) : 20),
      status === 'lost' ? 'Incumbent vendor held the AMC' : null]
  );
  dealIds.push(d.id);
}

const ACTIVITY_SEED = [
  ['call', 'Outbound call — 12 min', 'Confirmed Whitefield and Indiranagar go live first. Night-shift staff need training.', 0, 0, 0, 0, 2],
  ['email', 'Proposal v3 sent', 'Revised BOQ with 350 cameras across 14 stores, 3-year AMC bundled.', 0, 0, 0, 0, 4],
  ['meeting', 'Quarterly business review', 'Reviewed uptime 99.2%, tuned two false-alarm clusters.', 0, 0, 0, 0, 20],
  ['note', 'Scope gap flagged', 'Site 3 (Kukatpally) serviced since June but not on the AMC agreement.', 1, 1, 2, 2, 1],
  ['call', 'Renewal discussion', 'Kavita asked for the retention log format before signing.', 1, 1, 2, 2, 6],
  ['meeting', 'Technical evaluation walkthrough', '42 camera positions walked. IP66 housings quoted for the paint shop.', 2, 2, 3, 1, 3],
  ['email', 'Proposal v2 sent', 'Added fire alarm panel integration and 5-year support.', 2, 2, 3, 1, 2],
  ['call', 'Demo call — 25 min', 'Walked through temperature alerting and ERP integration question.', 3, 3, 4, 1, 8],
  ['note', 'Deal health dropped', 'Nine days in negotiation, no reply, price pressure from a local installer.', 3, 3, 4, 1, 7],
  ['note', 'Reference call agreed', 'Anita will speak to two hospitality prospects in November.', 4, 4, 6, 2, 2],
  ['meeting', 'Installation handover', 'Walkthrough with resort security team, two positions adjusted.', 4, 4, 6, 2, 15],
  ['call', 'Pilot scoping call', 'Agreed a single-terminal pilot. Site plan to follow this week.', 5, 5, 5, 0, 2],
  ['email', 'Capability deck sent', 'Thermal camera and analytics deck forwarded to IT security.', 5, 5, 5, 0, 6],
  ['note', 'Lead converted from website form', 'Inbound enquiry about multi-site coverage.', 0, 6, null, 0, 9]
];
for (const [type, subject, body, ci, cti, di, ownerIdx, daysAgo] of ACTIVITY_SEED) {
  await q(
    `insert into activities (org_id, type, subject, body, contact_id, company_id, deal_id, owner_id, occurred_at, created_by)
     values ($1,$2,$3,$4,$5,$6,$7,$8, now() - ($9 || ' days')::interval, null)`,
    [org.id, type, subject, body, contactIds[cti], companyIds[ci], di === null ? null : dealIds[di],
      memberIds[ownerIdx], String(daysAgo)]
  );
}

const TASKS = [
  ['Call Kavita Rao about AMC scope for site 3', 'High', 'open', 0, -1, 'Sunrise Hospitals'],
  ['Send revised proposal to Deccan Precision', 'High', 'open', 1, 0, 'Deal D-2405'],
  ['Site survey — new academic block', 'Medium', 'open', 2, 1, 'Vidya Institute'],
  ['Chase invoice INV-2291 (overdue)', 'High', 'open', 3, -2, 'Finance'],
  ['Prepare QBR deck for Meridian Retail', 'Medium', 'in_progress', 0, 4, 'Meridian Retail Group'],
  ['Approve 6% discount request — Meridian', 'High', 'open', 4, 0, 'Approval'],
  ['Update lead source mapping for imports', 'Low', 'done', 4, -6, 'Data quality']
];
for (const [title, priority, status, ownerIdx, dueOffset, related] of TASKS) {
  await q(
    `insert into tasks (org_id, title, priority, status, assignee_id, due_date, related_type, completed_at)
     values ($1,$2,$3,$4,$5, current_date + $6::int, 'general', $7)`,
    [org.id, title, priority.toLowerCase(), status, memberIds[ownerIdx], dueOffset, status === 'done' ? new Date() : null]
  );
  void related;
}

for (const [number, subject, ci, cti, priority, status, assigneeIdx, category] of TICKETS) {
  const slaHours = priority === 'critical' ? 4 : priority === 'high' ? 8 : 24;
  await q(
    `insert into tickets (org_id, number, subject, description, contact_id, company_id, priority, status,
                          category, assignee_id, sla_due_at, resolved_at, created_at, csat)
     values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,
             case when $2 = 'TKT-1084' then now() - interval '90 minutes'
                  else now() - interval '2 hours' + ($11 || ' hours')::interval end,
             $12, now() - interval '1 day', $13)`,
    [org.id, number, subject, 'Reported by the customer through the support inbox.', contactIds[cti],
      companyIds[ci], priority, status, category, memberIds[assigneeIdx], String(slaHours),
      status === 'resolved' ? new Date() : null,
      status === 'resolved' ? 5 : null]
  );
}

for (const [sku, name, category, price, tax, stock, reorder] of PRODUCTS) {
  await q(
    `insert into products (org_id, sku, name, category, unit_price, tax_rate, stock_qty, reorder_point)
     values ($1,$2,$3,$4,$5,$6,$7,$8)`,
    [org.id, sku, name, category, price, tax, stock, reorder]
  );
}

const quotation = await one(
  `insert into quotations (org_id, number, deal_id, contact_id, company_id, status, issue_date, valid_until,
                           subtotal, tax_total, total, terms, created_by)
   values ($1,'QT-2026-0114',$2,$3,$4,'sent', current_date - 6, current_date + 24,
           594000, 106920, 700920, 'Payment 40% advance, 60% on handover. Validity 30 days.', null)
   returning *`,
  [org.id, dealIds[3], contactIds[2], companyIds[2]]
);
await q(
  `insert into quotation_items (org_id, quotation_id, description, qty, unit_price, tax_rate, line_total, position)
   values ($1,$2,'4MP IP dome camera',40,6400,18,302080,0),
          ($1,$2,'32-channel NVR with 8TB storage',3,68000,18,240720,1),
          ($1,$2,'Installation and commissioning',1,51200,18,60416,2)`,
  [org.id, quotation.id]
);

const invoice = await one(
  `insert into invoices (org_id, number, deal_id, contact_id, company_id, status, issue_date, due_date,
                         subtotal, tax_total, total, amount_paid)
   values ($1,'INV-2291',$2,$3,$4,'sent', current_date - 32, current_date - 2, 661017, 118983, 780000, 312000)
   returning *`,
  [org.id, dealIds[6], contactIds[4], companyIds[4]]
);
await q(
  `insert into invoice_items (org_id, invoice_id, description, qty, unit_price, tax_rate, line_total, position)
   values ($1,$2,'Lobby and parking camera coverage — supply and install',1,661017,18,780000,0)`,
  [org.id, invoice.id]
);
await q(
  `insert into payments (org_id, invoice_id, amount, method, status, received_at)
   values ($1,$2,312000,'bank_transfer','succeeded', now() - interval '20 days')`,
  [org.id, invoice.id]
);

const project = await one(
  `insert into projects (org_id, name, deal_id, company_id, status, start_date, end_date, budget, spent, progress, manager_id)
   values ($1,'Meridian Phase 1 — 6 stores',$2,$3,'active', current_date - 40, current_date + 20, 2400000, 1610000, 68, $4)
   returning *`,
  [org.id, dealIds[6], companyIds[0], memberIds[2]]
);
for (const [i, [name, dueOffset, done]] of [
  ['Site survey and drawings', -30, true], ['Camera and NVR procurement', -18, true],
  ['Installation — 4 stores', 5, false], ['Commissioning and handover', 18, false]
].entries()) {
  await q(
    `insert into milestones (org_id, project_id, name, due_date, completed_at, position)
     values ($1,$2,$3, current_date + $4::int, $5, $6)`,
    [org.id, project.id, name, dueOffset, done ? new Date() : null, i]
  );
}

await q(
  `insert into workflows (org_id, name, description, status, trigger, conditions, actions)
   values ($1,'New lead — assign and set a first response task',
           'Every inbound lead gets an owner and a two-day first-response task.','active',
           '{"event":"lead.created","entity":"lead"}',
           '[{"field":"source","op":"eq","value":"website"}]',
           '[{"type":"create_task","title":"First response to {{name}}","dueInDays":1,"priority":"high"},
             {"type":"notify","title":"New website lead","body":"A new lead arrived from the website form."}]'),
          ($1,'Deal won — kick off delivery',
           'When a deal is won, create the onboarding task and log the handover activity.','active',
           '{"event":"deal.won","entity":"deal"}','[]',
           '[{"type":"create_task","title":"Kick off delivery for {{title}}","dueInDays":3,"priority":"high"},
             {"type":"log_activity","subject":"Deal won — handover to delivery","body":"Workflow created this handover note."},
             {"type":"send_email","to":"customer","subject":"Thank you — next steps","body":"Draft queued for approval."}]')`,
  [org.id]
);

await q(
  `insert into custom_fields (org_id, entity, key, label, type, options, position)
   values ($1,'deal','site_count','Number of sites','number','[]',0),
          ($1,'deal','camera_count','Camera count','number','[]',1),
          ($1,'contact','preferred_language','Preferred language','select','["English","Hindi","Kannada"]',0)`,
  [org.id]
);

await q(
  `insert into subscriptions (org_id, plan, status, seats, current_period_end, usage, limits)
   values ($1,'professional','active',20, now() + interval '24 days',
           '{"ai_credits":680,"emails":1240}','{"seats":20,"ai_credits":2000,"emails":5000}')`,
  [org.id]
);

for (const provider of ['gmail', 'google_calendar', 'whatsapp', 'razorpay', 'slack']) {
  await q(
    `insert into integrations (org_id, provider, status) values ($1,$2,'disconnected')`,
    [org.id, provider]
  );
}

await q(
  `insert into notifications (org_id, user_id, type, title, body, link)
   select $1, u.id, 'alert', 'SLA breach on TKT-1084', 'NVR offline at Meridian Whitefield for over 2 hours.', '/support'
     from users u join members m on m.user_id = u.id where m.org_id = $1 and m.role_id in
       (select id from roles where org_id = $1 and key in ('owner','manager','support'))`,
  [org.id]
);

await q(
  `insert into audit_logs (org_id, actor_name, action, entity, created_at)
   values ($1,'Seed script','org.created','organisation', now() - interval '8 months')`,
  [org.id]
);

const counts = await one(`
  select (select count(*) from contacts where org_id = $1)::int as contacts,
         (select count(*) from leads where org_id = $1)::int as leads,
         (select count(*) from deals where org_id = $1)::int as deals,
         (select count(*) from tickets where org_id = $1)::int as tickets,
         (select count(*) from activities where org_id = $1)::int as activities`, [org.id]);

console.log('Demo workspace ready');
console.log(`  org      : ${org.name} (${org.slug})`);
console.log(`  users    : ${USERS.map(u => u.email).join(', ')}`);
console.log(`  password : ${PASSWORD}`);
console.log(`  records  : ${JSON.stringify(counts)}`);
process.exit(0);
