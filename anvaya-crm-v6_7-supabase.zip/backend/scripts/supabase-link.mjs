#!/usr/bin/env node
// ============================================================================
// Checks the link between Anvaya and your Supabase project from both sides:
//
//   1. REST   SUPABASE_URL + SUPABASE_ANON_KEY   (the browser-facing door)
//   2. SQL    DATABASE_URL                       (the door the Express backend uses)
//
//   node scripts/supabase-link.mjs
//
// Loads backend/.env automatically. Exit code 0 only if the SQL door works,
// because that is the one the backend cannot run without.
// ============================================================================

import { loadEnv } from './lib-env.mjs';
loadEnv();

const G = '\x1b[32m', R = '\x1b[31m', Y = '\x1b[33m', D = '\x1b[2m', O = '\x1b[0m';
const pass = (m) => console.log(`${G}PASS${O}  ${m}`);
const fail = (m, fix) => { console.log(`${R}FAIL${O}  ${m}`); if (fix) console.log(`${D}      → ${fix}${O}`); };
const warn = (m, why) => { console.log(`${Y}WARN${O}  ${m}`); if (why) console.log(`${D}      → ${why}${O}`); };

export function decodeJwt(token) {
  try { return JSON.parse(Buffer.from(String(token).trim().split('.')[1], 'base64url').toString('utf8')); }
  catch { return null; }
}

/** REST check. Returns { ok, reachable } and prints what it found. */
export async function checkRest({ url, anonKey, fetchImpl = fetch, timeoutMs = 8000 }) {
  if (!url || !anonKey) { fail('SUPABASE_URL / SUPABASE_ANON_KEY missing', 'Add both to backend/.env'); return { ok: false, reachable: false }; }

  const claims = decodeJwt(anonKey);
  const host = (() => { try { return new URL(url).hostname; } catch { return ''; } })();
  const refFromUrl = host.split('.')[0];
  if (!claims) { fail('anon key is not a valid JWT', 'Copy it again from Settings → API → anon public.'); return { ok: false, reachable: false }; }
  if (claims.role !== 'anon') {
    fail(`this key has role "${claims.role}", not "anon"`,
      claims.role === 'service_role'
        ? 'That is the service_role key and bypasses all security. Rotate it in Settings → API and use the anon key.'
        : 'Use the anon public key.');
    return { ok: false, reachable: false };
  }
  if (claims.ref !== refFromUrl) { fail(`key belongs to project "${claims.ref}" but the URL is "${refFromUrl}"`, 'Use the URL and key from the same project.'); return { ok: false, reachable: false }; }
  if (claims.exp && claims.exp * 1000 < Date.now()) { fail('anon key has expired', 'Copy the current key from Settings → API.'); return { ok: false, reachable: false }; }
  pass(`anon key is valid for project ${claims.ref}`);

  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const res = await fetchImpl(`${url.replace(/\/$/, '')}/rest/v1/organisations?select=id&limit=1`, {
      headers: { apikey: anonKey, Authorization: `Bearer ${anonKey}` }, signal: ctl.signal
    });
    if (res.status === 401 || res.status === 403) { fail(`Supabase rejected the anon key (${res.status})`, 'Copy the current anon key from Settings → API.'); return { ok: false, reachable: true }; }
    if (res.status === 404) { warn('REST reached, but the "organisations" table is not exposed', 'Run supabase/anvaya-supabase.sql in the SQL editor.'); return { ok: true, reachable: true }; }
    const body = await res.json().catch(() => null);
    if (res.ok && Array.isArray(body) && body.length === 0) pass('REST reachable; anon key sees no customer rows (row-level security is protecting them)');
    else if (res.ok && Array.isArray(body) && body.length > 0) { fail('the anon key can read customer data', 'Row-level security is not enforced. Re-run the RLS section of anvaya-supabase.sql before storing real data.'); return { ok: false, reachable: true }; }
    else pass(`REST reachable (HTTP ${res.status})`);
    return { ok: true, reachable: true };
  } catch (err) {
    warn(`could not reach ${host}`, err.name === 'AbortError' ? 'Timed out.' : `${err.message}. Check the machine's internet access and firewall.`);
    return { ok: false, reachable: false };
  } finally { clearTimeout(timer); }
}

/** SQL check. Reuses the repo's own doctor. */
export async function checkSql(databaseUrl) {
  if (!databaseUrl || /[<>]|YOUR[-_ ]?DB[-_ ]?PASSWORD/i.test(databaseUrl)) {
    fail('DATABASE_URL is not filled in',
      'Supabase → Settings → Database → Connection string → URI. Replace the password placeholder with your database password (percent-encode @ as %40).');
    return false;
  }
  const { Pool } = await import('pg');
  const { runChecks } = await import('./check-supabase.mjs');
  const pool = new Pool({ connectionString: databaseUrl, max: 1, ssl: process.env.DATABASE_SSL === '0' ? false : { rejectUnauthorized: false } });
  try {
    const results = await runChecks(pool, { log: () => {} });
    return results.every((r) => r.pass);
  } finally { await pool.end().catch(() => {}); }
}

async function main() {
  console.log('Supabase link check\n');
  const rest = await checkRest({ url: process.env.SUPABASE_URL, anonKey: process.env.SUPABASE_ANON_KEY });
  console.log('');
  const sql = await checkSql(process.env.DATABASE_URL);
  console.log('');
  if (!sql) console.log(`${R}The backend cannot use Supabase yet.${O} The REST result above does not change that: the backend talks SQL.`);
  else console.log(`${G}Ready.${O} Start with: node scripts/start-supabase.mjs`);
  if (!rest.ok && sql) console.log(`${Y}Note:${O} REST is only needed if a browser talks to Supabase directly; the backend does not use it.`);
  process.exit(sql ? 0 : 1);
}

import { fileURLToPath } from 'node:url';
import path from 'node:path';
if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) main();
