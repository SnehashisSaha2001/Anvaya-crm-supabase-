#!/usr/bin/env node
// ============================================================================
// Supabase connection doctor.
//
//   DATABASE_URL="postgresql://postgres.<ref>:<password>@aws-0-<region>.pooler.supabase.com:6543/postgres" \
//     node scripts/check-supabase.mjs
//
// It answers one question: can this Anvaya backend actually use that database?
// Each check names the fix when it fails. Exit code 0 means the link is good.
// ============================================================================

const GREEN = '\x1b[32m', RED = '\x1b[31m', DIM = '\x1b[2m', OFF = '\x1b[0m';
const ok = (m) => console.log(`${GREEN}PASS${OFF}  ${m}`);
const bad = (m, fix) => { console.log(`${RED}FAIL${OFF}  ${m}`); if (fix) console.log(`${DIM}      → ${fix}${OFF}`); };

/** Runs every check against any client exposing query(sql, params). */
export async function runChecks(client, { log = console.log } = {}) {
  const results = [];
  const record = (name, pass, detail, fix) => {
    results.push({ name, pass, detail, fix });
    if (pass) ok(name); else bad(name + (detail ? ` — ${detail}` : ''), fix);
  };

  // 1 · can we talk to it at all
  let version = null;
  try {
    const r = await client.query('select version() as v');
    version = r.rows[0].v.split(' ').slice(0, 2).join(' ');
    record('connected to PostgreSQL', true);
    log(`${DIM}      ${version}${OFF}`);
  } catch (err) {
    record('connected to PostgreSQL', false, err.message,
      'Check DATABASE_URL. Use the Connection pooling string (port 6543) from Supabase → Settings → Database, and URL-encode the password (@ becomes %40).');
    return results;
  }

  // 2 · is the Anvaya schema there
  try {
    const t = await client.query(
      `select count(*)::int n from information_schema.tables where table_schema = 'public'`);
    const n = t.rows[0].n;
    record(`schema present (${n} tables)`, n >= 51,
      n === 0 ? 'no tables' : n < 51 ? 'incomplete' : null,
      'Run supabase/anvaya-supabase.sql in the Supabase SQL editor.');
  } catch (err) { record('schema present', false, err.message, 'Run supabase/anvaya-supabase.sql.'); }

  // 3 · row level security actually enforced
  try {
    const p = await client.query(`select count(*)::int n from pg_policies`);
    const n = p.rows[0].n;
    record(`row-level security policies (${n})`, n >= 150,
      n < 150 ? 'fewer than expected' : null,
      'The RLS section of anvaya-supabase.sql did not run to completion.');
  } catch (err) { record('row-level security policies', false, err.message, null); }

  // 4 · the identity helpers the policies call
  try {
    const f = await client.query(
      `select proname from pg_proc p join pg_namespace n on n.oid = p.pronamespace
        where n.nspname = 'app' and proname in ('uid','current_org','has_perm')`);
    const found = f.rows.map(r => r.proname);
    const missing = ['uid', 'current_org', 'has_perm'].filter(x => !found.includes(x));
    record('identity helpers exist', missing.length === 0,
      missing.length ? `missing ${missing.join(', ')}` : null,
      'Run 00_helpers.sql (or the whole anvaya-supabase.sql).');
  } catch (err) { record('identity helpers exist', false, err.message, 'Run 00_helpers.sql.'); }

  // 5 · the API role can reach the tables (this is what broke in the first bundle)
  try {
    const g = await client.query(
      `select has_table_privilege('authenticated','public.leads','SELECT') as sel,
              has_table_privilege('authenticated','public.leads','INSERT') as ins`);
    const { sel, ins } = g.rows[0];
    record('authenticated role has table privileges', sel && ins, !sel ? 'no SELECT grant' : null,
      'Run the GRANT block from 00_helpers.sql. Grants to app_user do nothing for Supabase clients.');
  } catch (err) { record('authenticated role has table privileges', false, err.message, null); }

  // 6 · is there a workspace to log into
  let orgs = 0, users = 0;
  try {
    const o = await client.query(`select count(*)::int n from organisations`);
    const u = await client.query(`select count(*)::int n from users`);
    orgs = o.rows[0].n; users = u.rows[0].n;
    record(`workspace seeded (${orgs} org, ${users} user${users === 1 ? '' : 's'})`, orgs > 0 && users > 0,
      orgs === 0 ? 'no organisation yet' : users === 0 ? 'no user yet' : null,
      'Create your account, then run 03_seed.sql (or re-run anvaya-supabase.sql).');
  } catch (err) { record('workspace seeded', false, err.message, null); }

  // 7 · does a real request see its own rows through RLS
  if (users > 0) {
    try {
      const who = await client.query(`select user_id from members where status = 'active' limit 1`);
      if (who.rows.length) {
        await client.query('begin');
        await client.query(`set local role authenticated`);
        await client.query(`select set_config('request.jwt.claim.sub', $1, true)`, [who.rows[0].user_id]);
        const seen = await client.query(`select count(*)::int n from leads`);
        const orgSeen = await client.query(`select count(*)::int n from organisations`);
        await client.query('rollback');
        record('a signed-in user sees their own workspace through RLS',
          orgSeen.rows[0].n === 1,
          orgSeen.rows[0].n === 0 ? 'saw no organisation — identity is not resolving' : null,
          'Check that app.uid() falls back to auth.uid(), and that the request sets the JWT claim.');
        log(`${DIM}      that user sees ${seen.rows[0].n} lead(s)${OFF}`);
      }
    } catch (err) {
      await client.query('rollback').catch(() => {});
      record('a signed-in user sees their own workspace through RLS', false, err.message,
        'Re-run the helper section: app.uid() must be SECURITY DEFINER.');
    }
  }

  const failed = results.filter(r => !r.pass).length;
  log('');
  log(failed === 0
    ? `${GREEN}All checks passed — this backend can use that Supabase database.${OFF}`
    : `${RED}${failed} check(s) failed.${OFF} Fix those, then run this again.`);
  return results;
}

/* --------------------------------------------------------------- CLI ------ */
if (import.meta.url === `file://${process.argv[1]}`) {
  const url = process.env.DATABASE_URL;
  if (!url) {
    console.log(`${RED}DATABASE_URL is not set.${OFF}`);
    console.log('Get it from Supabase → Settings → Database → Connection string → URI,');
    console.log('then run:');
    console.log('  DATABASE_URL="postgresql://postgres.<ref>:<password>@aws-0-<region>.pooler.supabase.com:6543/postgres" \\');
    console.log('    node scripts/check-supabase.mjs');
    process.exit(1);
  }
  const { Client } = await import('pg');
  const client = new Client({
    connectionString: url,
    ssl: process.env.DATABASE_SSL === '0' ? false : { rejectUnauthorized: false }
  });
  try {
    await client.connect();
  } catch (err) {
    console.log(`${RED}Could not connect:${OFF} ${err.message}`);
    process.exit(1);
  }
  const results = await runChecks(client);
  await client.end();
  process.exit(results.some(r => !r.pass) ? 1 : 0);
}
