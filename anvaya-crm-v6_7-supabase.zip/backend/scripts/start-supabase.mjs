#!/usr/bin/env node
// ============================================================================
// Starts the unchanged Anvaya backend with Supabase as its primary database,
// and keeps a local backup mirror in the background.
//
//   node scripts/start-supabase.mjs
//
// What it does that `npm start` would not:
//   * loads backend/.env
//   * sets AUTO_MIGRATE=0  — src/server.js runs the self-hosted migrations on
//     boot; those create an app_user role and must never run against Supabase
//   * sets DB_USER_ROLE=authenticated so row-level security applies per request
//   * refuses to start with a clear message if DATABASE_URL is missing or still
//     a placeholder, instead of silently falling back to a local database
//   * runs the backup mirror every MIRROR_INTERVAL_MIN minutes (MIRROR=0 to disable)
//
// src/server.js and the rest of the backend are imported as they are.
// ============================================================================

import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadEnv } from './lib-env.mjs';

loadEnv();

const url = process.env.DATABASE_URL || '';
if (!url || /[<>]|YOUR[-_ ]?DB[-_ ]?PASSWORD/i.test(url)) {
  console.error('\nDATABASE_URL is not set to a real Supabase connection string.');
  console.error('Starting anyway would silently use a local database, which is not what you asked for.');
  console.error('Fix: Supabase → Settings → Database → Connection string → URI, then put it in backend/.env\n');
  process.exit(2);
}

process.env.AUTO_MIGRATE = '0';
process.env.DB_USER_ROLE = process.env.DB_USER_ROLE || 'authenticated';
process.env.NODE_ENV = process.env.NODE_ENV || 'production';

const { checkRest } = await import('./supabase-link.mjs');
const rest = await checkRest({ url: process.env.SUPABASE_URL, anonKey: process.env.SUPABASE_ANON_KEY });
if (!rest.ok) console.log('(REST check is informational; the backend only needs DATABASE_URL.)');

// Backup mirror — in-process, failures never take the server down.
if (process.env.MIRROR !== '0') {
  const { PGlite } = await import('@electric-sql/pglite');
  const { Pool } = await import('pg');
  const fs = await import('node:fs');
  const { runMirror } = await import('./supabase-mirror.mjs');

  const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
  const mirrorPath = process.env.MIRROR_PATH || path.join(root, '.data', 'backup');
  const everyMs = Math.max(1, Number(process.env.MIRROR_INTERVAL_MIN || 30)) * 60_000;
  fs.mkdirSync(path.dirname(mirrorPath), { recursive: true });

  let target, pool, busy = false;
  const tick = async () => {
    if (busy) return;
    busy = true;
    try {
      target ||= await (async () => { const p = new PGlite(mirrorPath); await p.waitReady; return p; })();
      pool ||= new Pool({ connectionString: url, max: 1, ssl: process.env.DATABASE_SSL === '0' ? false : { rejectUnauthorized: false } });
      const r = await runMirror(pool, target, { log: (m) => console.log(`[mirror] ${m}`) });
      fs.writeFileSync(path.join(path.dirname(mirrorPath), 'backup-status.json'),
        JSON.stringify({ at: new Date().toISOString(), tables: r.tables, rows: r.rows, ms: r.ms, drift: r.drift }, null, 2));
      console.log(`[mirror] backup updated: ${r.rows} rows, ${r.tables} tables, ${r.ms} ms`);
    } catch (err) {
      console.error(`[mirror] backup skipped, previous copy kept: ${err.message}`);
    } finally { busy = false; }
  };
  setTimeout(tick, 20_000).unref();           // let the server come up first
  setInterval(tick, everyMs).unref();
  console.log(`[mirror] local backup → ${mirrorPath} every ${everyMs / 60000} min`);
}

await import('../src/server.js');
