#!/usr/bin/env node
// ============================================================================
// Supabase → local backup mirror.
//
// Supabase is the primary database. This keeps a complete, self-contained copy
// of it on local disk (PGlite, the same engine the backend already uses when no
// DATABASE_URL is set), so that if Supabase is ever unreachable or the project
// is lost, the app can be started on the backup with no code changes:
//
//     DB_PATH=./.data/backup node src/server.js        (DATABASE_URL unset)
//
// Design rules:
//   * one direction only: Supabase → local. The backup never writes back, so
//     there is no second source of truth and no merge logic to get wrong.
//   * one consistent snapshot: the whole read happens in a single
//     REPEATABLE READ transaction, so related tables agree with each other.
//   * all-or-nothing: the local copy is replaced inside one transaction. A
//     failure at any point rolls back and leaves the previous backup intact.
//   * verified: row counts are compared table by table before commit.
//   * safe by refusal: if the connecting role cannot bypass row-level security
//     it would silently copy nothing, so the mirror stops and says why.
//
//   node scripts/supabase-mirror.mjs --once      one backup, then exit
//   node scripts/supabase-mirror.mjs --watch     repeat every MIRROR_INTERVAL_MIN (default 30)
// ============================================================================

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const PKG_ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const BATCH = 500;
const qi = (s) => '"' + String(s).replace(/"/g, '""') + '"';

async function listTables(client) {
  const r = await client.query(
    `select table_name from information_schema.tables
      where table_schema = 'public' and table_type = 'BASE TABLE' order by 1`);
  return r.rows.map((x) => x.table_name);
}

async function listColumns(client, table) {
  const r = await client.query(
    `select column_name, is_generated from information_schema.columns
      where table_schema = 'public' and table_name = $1 order by ordinal_position`, [table]);
  return r.rows.filter((c) => c.is_generated !== 'ALWAYS').map((c) => c.column_name);
}

/** Apply the repo's own migrations to the backup database if it is empty. */
export async function ensureLocalSchema(target, dir = path.join(PKG_ROOT, 'db', 'migrations')) {
  const has = await target.query(
    `select 1 from information_schema.tables where table_schema='public' and table_name='organisations'`);
  if (has.rows.length) return false;
  const files = fs.readdirSync(dir).filter((f) => f.endsWith('.sql')).sort();
  for (const f of files) await target.exec(fs.readFileSync(path.join(dir, f), 'utf8'));
  return true;
}

/**
 * source: { connect(): Promise<{query, release}> }   (a pg Pool, or anything shaped like one)
 * target: a PGlite instance
 * Returns { tables, rows, skipped, drift, ms }.
 */
export async function runMirror(source, target, { log = () => {} } = {}) {
  const started = Date.now();
  const src = await source.connect();
  let inSrcTx = false;
  try {
    // 1 · refuse to run as a role that RLS would blind
    const who = await src.query(
      `select current_user as u,
              coalesce((select rolsuper or rolbypassrls from pg_roles where rolname = current_user), false) as bypass`);
    if (!who.rows[0].bypass) {
      throw new Error(
        `The role "${who.rows[0].u}" cannot bypass row-level security, so a backup taken with it would be empty or partial. ` +
        `Use the postgres role in DATABASE_URL for the mirror (Supabase → Settings → Database → Connection string).`);
    }

    await ensureLocalSchema(target);

    const remoteTables = await listTables(src);
    const localTables = new Set(await listTables(target));
    const tables = remoteTables.filter((t) => localTables.has(t));
    const skipped = remoteTables.filter((t) => !localTables.has(t));
    if (skipped.length) log(`skipping tables that exist only in Supabase: ${skipped.join(', ')}`);

    // 2 · one consistent snapshot of the source
    await src.query('begin isolation level repeatable read read only');
    inSrcTx = true;

    const plan = [];
    const drift = [];
    for (const t of tables) {
      const rc = await listColumns(src, t);
      const lc = new Set(await listColumns(target, t));
      const cols = rc.filter((c) => lc.has(c));
      if (cols.length !== rc.length || cols.length !== lc.size) {
        drift.push({ table: t, onlyRemote: rc.filter((c) => !lc.has(c)), onlyLocal: [...lc].filter((c) => !rc.includes(c)) });
      }
      plan.push({ table: t, cols });
    }

    // 3 · replace the local copy atomically
    let total = 0;
    const counts = {};
    await target.transaction(async (tx) => {
      // The snapshot is internally consistent, so referential checks are
      // redundant while loading, and skipping them makes load order irrelevant.
      await tx.query(`set local session_replication_role = replica`);
      if (plan.length) {
        await tx.query(`truncate table ${plan.map((p) => 'public.' + qi(p.table)).join(', ')} restart identity cascade`);
      }

      for (const { table, cols } of plan) {
        const colList = cols.map(qi).join(', ');
        await src.query(`declare mirror_cur no scroll cursor for select to_jsonb(t) as j from public.${qi(table)} t`);
        let n = 0;
        for (;;) {
          const page = await src.query(`fetch ${BATCH} from mirror_cur`);
          if (!page.rows.length) break;
          const json = JSON.stringify(page.rows.map((r) => r.j));
          await tx.query(
            `insert into public.${qi(table)} (${colList})
             select ${colList} from jsonb_populate_recordset(null::public.${qi(table)}, $1::jsonb)`, [json]);
          n += page.rows.length;
        }
        await src.query('close mirror_cur');

        // 4 · verify before commit
        const expected = Number((await src.query(`select count(*)::bigint n from public.${qi(table)}`)).rows[0].n);
        const got = Number((await tx.query(`select count(*)::bigint n from public.${qi(table)}`)).rows[0].n);
        if (got !== expected || n !== expected) {
          throw new Error(`Row count mismatch on ${table}: Supabase ${expected}, backup ${got}. Backup left unchanged.`);
        }
        counts[table] = got;
        total += got;
      }
    });

    await src.query('commit');
    inSrcTx = false;
    return { tables: plan.length, rows: total, counts, skipped, drift, ms: Date.now() - started };
  } finally {
    if (inSrcTx) { try { await src.query('rollback'); } catch { /* connection already gone */ } }
    src.release();
  }
}

/* ---------------------------------------------------------------------- CLI -- */
async function main() {
  const { PGlite } = await import('@electric-sql/pglite');
  const { Pool } = await import('pg');

  if (!process.env.DATABASE_URL) {
    console.error('DATABASE_URL is not set. Put the Supabase connection string in backend/.env first.');
    process.exit(2);
  }
  const mirrorPath = process.env.MIRROR_PATH || path.join(PKG_ROOT, '.data', 'backup');
  fs.mkdirSync(path.dirname(mirrorPath), { recursive: true });

  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 1,
    ssl: process.env.DATABASE_SSL === '0' ? false : { rejectUnauthorized: false }
  });
  const target = new PGlite(mirrorPath);
  await target.waitReady;

  const once = async () => {
    const r = await runMirror(pool, target, { log: (m) => console.log(`[mirror] ${m}`) });
    const status = { at: new Date().toISOString(), tables: r.tables, rows: r.rows, ms: r.ms, drift: r.drift };
    fs.writeFileSync(path.join(path.dirname(mirrorPath), 'backup-status.json'), JSON.stringify(status, null, 2));
    console.log(`[mirror] ${r.rows} rows in ${r.tables} tables backed up in ${r.ms} ms → ${mirrorPath}`);
    if (r.drift.length) console.warn(`[mirror] column differences on: ${r.drift.map((d) => d.table).join(', ')} (see backup-status.json)`);
  };

  const watch = process.argv.includes('--watch');
  const everyMs = Math.max(1, Number(process.env.MIRROR_INTERVAL_MIN || 30)) * 60_000;
  try {
    await once();
    while (watch) {
      await new Promise((res) => setTimeout(res, everyMs));
      try { await once(); } catch (err) { console.error(`[mirror] failed, previous backup kept: ${err.message}`); }
    }
  } catch (err) {
    console.error(`[mirror] failed: ${err.message}`);
    process.exitCode = 1;
  } finally {
    if (!watch) { await pool.end(); await target.close(); }
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) main();
