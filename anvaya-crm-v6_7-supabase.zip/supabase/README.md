# Anvaya CRM — Supabase SQL

**`anvaya-supabase.sql` is the whole database in one file.** Paste it into the
Supabase SQL editor and run it. That is the normal path; the numbered files below
exist only if you prefer to apply them one at a time.

Run it a second time after you create your first user account — the seed skips
politely until that account exists, then creates the workspace on the next run.

| File | What it does |
|---|---|
| `00_helpers.sql` | `app` schema, identity and permission functions, grants to `authenticated` |
| `01_schema.sql` | 51 tables |
| `02_rls.sql` | 182 row-level-security policies |
| `03_seed.sql` | one usable workspace: org, 9 roles, 6 pipeline stages, numbering |
| `04_optional_supabase_auth.sql` | only if the browser talks to Supabase directly (see below) |

## Before you start

Create the project, then **create your user account first** — either
Authentication → Users → *Add user* in Supabase, or let the app register it.
`03_seed.sql` looks that account up by email and attaches it to the workspace.

## Run

Paste each file into the SQL editor and press Run. Or with the CLI:

```bash
supabase db execute --file supabase/00_helpers.sql
supabase db execute --file supabase/01_schema.sql
supabase db execute --file supabase/02_rls.sql
supabase db execute --file supabase/03_seed.sql
```

Then edit the two values at the top of `03_seed.sql` (`v_email`, `v_org`) and run
it again — it refuses to duplicate a workspace that already exists.

## Two ways the identity works

The policies ask one question: *who is calling, and which organisation are they
in?* Both answers come from `app.uid()` and `app.current_org()`, which accept
either source:

**Path A — your Express backend (this is what you have today).**
The backend keeps its own sessions and sets the context per transaction:

```sql
begin;
select set_config('app.user_id', '<user-uuid>', true);
select set_config('app.org_id',  '<org-uuid>',  true);
-- queries here are scoped and permission-checked
commit;
```

Point it at Supabase by setting one environment variable on the backend:

```
DATABASE_URL=postgresql://postgres.<project-ref>:<password>@aws-0-<region>.pooler.supabase.com:6543/postgres
```

The backend also needs `ENCRYPTION_KEY` (32+ characters) for MFA secrets and
provider tokens.

**Path B — browser talks to Supabase directly, no backend.**
Run `04_optional_supabase_auth.sql`, enable the providers you want in
Authentication, and use the project's `anon` key in the browser. The policies
then read `auth.uid()` from the JWT. The `service_role` key must never appear in
frontend code — it bypasses RLS entirely.

## What is enforced, and what is verified

Every organisation-owned table carries `org_id`, and every policy is written as:

```sql
using (org_id = app.current_org() and app.has_perm('lead.read'))
```

`FORCE ROW LEVEL SECURITY` is set on each table, because the SQL editor runs as a
superuser and would otherwise bypass its own policies.

Verified against a real PostgreSQL 16 instance with `auth.uid()` and the
`authenticated` role stubbed in:

- 51 tables, 182 policies created without error
- a user in organisation A sees only organisation A's rows
- inserting a row for organisation B is rejected by the policy
- a member with only `lead.read` can read but cannot insert
- the seed produces 1 org, 9 roles, 6 stages, 4 document sequences, and is
  idempotent on a second run

## Cost and sizing

51 tables and 182 policies are trivial for the free tier. The database will grow
with activity, not with the schema: the largest tables in practice are
`activities`, `audit_logs` and `ai_runs`. Turn on daily backups in
Database → Backups before you put real customer data in.
